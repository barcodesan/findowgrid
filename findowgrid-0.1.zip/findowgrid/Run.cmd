@echo off
setlocal
cd /d "%~dp0"
where dotnet >nul 2>&1
if errorlevel 1 (
 echo Install the .NET 10 SDK for Windows x64, then run this file again.
 pause
 exit /b 1
)
dotnet run --project src\findowgrid.TestHost\findowgrid.TestHost.csproj -c Release
if errorlevel 1 pause
