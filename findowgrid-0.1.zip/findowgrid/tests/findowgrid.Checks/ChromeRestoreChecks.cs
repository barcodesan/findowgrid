using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.Json.Serialization;
using findowgrid.Engine.Models;
using findowgrid.Engine.Services;
using findowgrid.Engine.Storage;
internal static class ChromeRestoreChecks
{
    public static async Task<int> Run()
    {
        int count=0;
        void Check(bool ok,string name) { if(!ok) throw new Exception("FAIL: "+name); Console.WriteLine("PASS: "+name); count++; }
        const string chrome=@"C:\Program Files\Google\Chrome\Application\chrome.exe";
        var area=new PixelRect(0,0,1920,1040); var monitor=new MonitorSnapshot("DISPLAY1",area,area,true);
        WindowInfo Window(int handle,string title)=>new((nint)handle,700,777,
            new("chrome",chrome,"Chrome_WidgetWin_1",title),area,area,WindowState.Normal,false,monitor,96,null);
        var a=Window(10,"TradingView - Google Chrome"); var b=Window(20,"Calendar - Google Chrome");
        WindowSnapshot Snapshot(WindowInfo w)=>new(1,DateTimeOffset.UtcNow,w.Identity,area,w.State,false,monitor,96);
        var entry=new WorkspaceWindow(Guid.NewGuid(),Snapshot(a),new(LaunchKind.Url,Url:"https://example.com/chart?a=1&b=2",WaitSeconds:1));
        var prepared=BrowserLaunchPolicy.Prepare(entry);
        var command=LaunchCommand.Create(prepared);
        Check(command.FileName==chrome && !command.UseShellExecute,"saved Chrome URL bypasses default-browser shell");
        Check(command.ArgumentList.SequenceEqual(new[]{"--new-window",entry.Launch!.Url!}),"actual process arguments request one independent Chrome window with intact URL");
        Check(entry.Launch!.BrowserPath==null && entry.Launch.Arguments==null,"launch preparation does not mutate saved entry");
        var programEntry=entry with { Launch=new(LaunchKind.Application,chrome,Url:"https://example.com/chart") };
        Check(LaunchCommand.Create(BrowserLaunchPolicy.Prepare(programEntry)).ArgumentList.Last()=="https://example.com/chart","Chrome application entries use dedicated URL field");
        var legacyArgs=entry with { Launch=new(LaunchKind.Application,chrome,["--profile-directory=Profile 2","https://example.com/chart"]) };
        var legacyCommand=LaunchCommand.Create(BrowserLaunchPolicy.Prepare(legacyArgs));
        Check(legacyCommand.ArgumentList.SequenceEqual(new[]{"--new-window","--profile-directory=Profile 2","https://example.com/chart"}),"legacy URL arguments retain profile and receive independent-window switch");
        var repeat=BrowserLaunchPolicy.Prepare(entry with { Launch=prepared });
        Check(repeat.Arguments!.Count(s=>s=="--new-window")==1 && repeat.Arguments!.Count(s=>s==entry.Launch.Url)==1,"repeated preparation does not duplicate flags or URL");
        var defaultEntry=entry with { Launch=entry.Launch with { BrowserWindow=BrowserWindowMode.BrowserDefault } };
        Check(LaunchCommand.Create(BrowserLaunchPolicy.Prepare(defaultEntry)).UseShellExecute,"explicit browser-default mode preserves shell behavior");
        var other=entry with { Launch=entry.Launch with { BrowserPath=@"C:\Other\browser.exe" } };
        Check(BrowserLaunchPolicy.Prepare(other)==other.Launch,"other browsers keep their existing launch behavior");
        Check(BrowserLaunchPolicy.IsChrome(@"C:\Apps\CHROME.EXE") && !BrowserLaunchPolicy.IsChrome(@"C:\Apps\notchrome.exe"),"Chrome detection uses exact executable basename");
        foreach(var bad in new[]{
            new LaunchSpec(LaunchKind.Application,chrome),
            new LaunchSpec(LaunchKind.Application,chrome,Url:"javascript:alert(1)"),
            new LaunchSpec(LaunchKind.Application,chrome,["--new-tab","https://example.com"]),
            new LaunchSpec(LaunchKind.Application,chrome,["--app=https://example.com"]),
            new LaunchSpec(LaunchKind.Url,Url:"https://example.com",BrowserPath:@"C:\Other\browser.exe",BrowserWindow:BrowserWindowMode.NewWindow) })
        {
            bool rejected=false;
            try { BrowserLaunchPolicy.Prepare(entry with { Launch=bad }); }
            catch(Exception ex) when(ex is InvalidOperationException or InvalidDataException) { rejected=true; }
            Check(rejected,"unsafe or incomplete independent-window launch is rejected before execution");
        }
        bool invalidEnum=false;
        try { LaunchValidation.Validate(entry.Launch with { BrowserWindow=(BrowserWindowMode)99 }); } catch(InvalidDataException) { invalidEnum=true; }
        Check(invalidEnum,"invalid browser mode rejected");
        var effective=entry with { Launch=prepared };
        var before=Window(1,"Unrelated - Google Chrome");
        var changed=before with { Identity=a.Identity };
        var context=new LaunchContext([before],new(999,"Chrome forwarded to existing process"));
        Check(WindowMatcher.Resolve(effective,null,[changed],launch:context).Window==null,"tab title change in existing Chrome window cannot satisfy independent-window request");
        Check(WindowMatcher.Resolve(effective,null,[changed,a],launch:context).Window==a,"fresh window identified by path class and title despite forwarded PID");
        Check(WindowMatcher.Resolve(effective with { Match=new("TradingView") },null,[Window(4,"TradingView EURUSD 1.12 - Google Chrome")],launch:context).Window!=null,"explicit title pattern supports changing chart prices in a fresh Chrome window");
        Check(WindowMatcher.Resolve(effective,null,[Window(2,a.Title),a],launch:context).Status==MatchStatus.Ambiguous,"two fresh identical Chrome candidates remain ambiguous");
        Check(WindowMatcher.Resolve(effective,null,[Window(3,"New Tab")],launch:new([],new(700,"started"))).Window==null,"new tab or startup placeholder is not accepted just because PID matches");
        Check(WindowMatcher.Resolve(effective,null,[a],new HashSet<nint>{a.Handle},context).Window==null,"one newly opened window cannot serve two saved entries");
        Check(WindowMatcher.Resolve(effective,null,[a]).Window==a,"already running matching Chrome window remains reusable");
        var fake=new FakeDesktop([before]); int calls=0;
        var entries=new[]{entry,entry with { Id=Guid.NewGuid(),Snapshot=Snapshot(b),Launch=entry.Launch with { Url="https://example.com/calendar" } }};
        var workspace=new Workspace(Guid.NewGuid(),"Chrome",DateTimeOffset.UtcNow,entries.ToList());
        var service=new WorkspaceService(fake,new TestLauncher(spec=>
        {
            Check(LaunchCommand.Create(spec).ArgumentList.First()=="--new-window","each missing Chrome entry launches as separate window");
            calls++; fake.Live.Add(calls==1?a:b);
            if(calls==2) fake.Live[0]=before with { Identity=b.Identity }; // A competing old tab change must be ignored.
            return new(999,"forwarded");
        }));
        var result=await service.OpenAsync(workspace,[workspace]);
        Check(result.Completed && calls==2 && fake.Restored.Contains(a.Handle) && fake.Restored.Contains(b.Handle),"two cold Chrome entries restore to two distinct windows even when launcher PID exits");
        Check(!fake.Restored.Contains(before.Handle),"unrelated old Chrome window is not moved by launch attribution");
        result=await service.OpenAsync(workspace,[workspace]);
        Check(result.Completed && calls==2,"second OPEN reuses bound Chrome windows without opening duplicates");
        fake=new FakeDesktop([a]); calls=0;
        var missingUrl=entry with { Launch=new(LaunchKind.Application,chrome,WaitSeconds:1) };
        var coordinator=new WindowLaunchCoordinator(fake,new TestLauncher(_=>{calls++;return new(null,"");}),TimeSpan.FromMilliseconds(1));
        Check((await coordinator.LaunchAndWaitAsync(workspace.Id,missingUrl,new HashSet<nint>(),CancellationToken.None)).Window==a && calls==0,"missing URL does not block reuse of already-open saved Chrome window");
        fake.Live.Clear(); bool needsUrl=false;
        try { await coordinator.LaunchAndWaitAsync(workspace.Id,missingUrl,new HashSet<nint>(),CancellationToken.None); }
        catch(InvalidOperationException ex) { needsUrl=ex.Message.Contains("URL"); }
        Check(needsUrl && calls==0,"closed Chrome without URL reports configuration need without launching blank windows");
        var folder=Path.Combine(Path.GetTempPath(),"findowgrid-chrome-"+Guid.NewGuid());
        try
        {
            var store=new WorkspaceStore(Path.Combine(folder,"workspaces.json"));
            var doc=store.Save(new(2,0,null,[workspace]),0);
            Check(store.Load().Workspaces[0].Windows[0].Launch!.BrowserWindow==BrowserWindowMode.Automatic,"new browser policy roundtrips in Workspace JSON");
            var options=new JsonSerializerOptions { PropertyNamingPolicy=JsonNamingPolicy.SnakeCaseLower,Converters={new JsonStringEnumConverter()} };
            var json=JsonNode.Parse(JsonSerializer.Serialize(doc,options))!;
            foreach(var window in json["workspaces"]![0]!["windows"]!.AsArray()) window!["launch"]!.AsObject().Remove("browser_window");
            File.WriteAllText(store.FilePath,json.ToJsonString());
            var loaded=store.Load();
            Check(loaded.Workspaces[0].Windows[0].Launch!.BrowserWindow==BrowserWindowMode.Automatic,"existing Phase 5 JSON without mode receives automatic Chrome policy");
            Check(BrowserLaunchPolicy.Prepare(loaded.Workspaces[0].Windows[0]).Arguments!.Contains("--new-window"),"legacy URL Workspace gets fix without recreating Workspace");
        }
        finally { if(Directory.Exists(folder)) Directory.Delete(folder,true); }
        return count;
    }
}
