using findowgrid.Engine.Models;
using findowgrid.Engine.Services;
using findowgrid.Engine.Storage;
internal static class Phase5Checks
{
    public static int Run()
    {
        int count=0;
        void Check(bool value,string name) { if(!value) throw new Exception("FAIL: "+name); Console.WriteLine("PASS: "+name); count++; }
        var primary=new MonitorSnapshot("DISPLAY1",new(0,0,1920,1080),new(0,0,1920,1040),true,"monitor-A");
        var saved=new MonitorSnapshot("DISPLAY2",new(-1920,0,1920,1080),new(-1920,0,1920,1040),false,"monitor-B");
        var moved=saved with { DeviceName="DISPLAY3",Bounds=new(1920,-200,2560,1440),WorkArea=new(1920,-200,2560,1400) };
        Check(MonitorSelector.Select(saved,[primary,moved])==moved,"device path survives changed display number, location and resolution");
        Check(MonitorSelector.Select(saved,[primary,moved with { DevicePath="MONITOR-b" }]).DeviceName=="DISPLAY3","monitor identity comparison is case insensitive");
        Check(MonitorSelector.Select(saved,[primary,saved with { DevicePath="replacement" }])==primary,"missing device never matches reused display number");
        Check(MonitorSelector.Select(saved,[primary,moved,saved])==primary,"ambiguous device identity falls back safely");
        Check(MonitorSelector.Select(saved with { DevicePath=null },[primary,saved])==saved,"legacy snapshot matches exact display geometry");
        Check(MonitorSelector.Select(saved with { DevicePath=null },[primary,moved])==primary,"legacy uncertain topology falls back to primary");
        Check(MonitorSelector.Select(saved,[moved with { DevicePath="other",IsPrimary=false }]).DevicePath=="other","missing primary falls back to first available monitor");
        try { MonitorSelector.Select(saved,[]); throw new Exception("Empty accepted"); } catch(InvalidOperationException) { count++; }
        var mapped=PlacementGeometry.Map(saved.WorkArea,saved.WorkArea,primary.WorkArea);
        Check(mapped==primary.WorkArea,"disconnected monitor restores inside active work area");
        var hotkey=new HotkeySpec(9,49); hotkey.Validate();
        Check(hotkey.ToString()=="Win + Alt + 1","shortcut label corresponds to native modifiers");
        Check(new HotkeySpec(6,122).ToString()=="Ctrl + Shift + F11","function key label");
        foreach(var invalid in new[]{new HotkeySpec(0,49),new HotkeySpec(16,49),new HotkeySpec(2,123),new HotkeySpec(1,13)})
        { try { invalid.Validate(); throw new Exception("Bad shortcut accepted"); } catch(InvalidDataException) { count++; } }
        var snapshot=new WindowSnapshot(1,DateTimeOffset.UtcNow,new("app","C:\\app.exe","Class","Title"),new(10,10,800,600),WindowState.Normal,false,primary,144);
        var workspace=new Workspace(Guid.NewGuid(),"FX",DateTimeOffset.UtcNow,[new(Guid.NewGuid(),snapshot)],hotkey);
        var registrations=new Dictionary<int,HotkeySpec>();
        HotkeySpec? blocked=null;
        using(var bindings=new HotkeyBindings((id,key)=> { if(key==blocked) return false; registrations.Add(id,key); return true; },id=>registrations.Remove(id)))
        {
            bindings.Apply([workspace]); int originalId=registrations.Single().Key;
            Check(bindings.Find(originalId)==workspace.Id,"registered shortcut dispatches correct Workspace");
            var second=workspace with { Id=Guid.NewGuid(),Name="Second",Hotkey=new(9,50) };
            var third=workspace with { Id=Guid.NewGuid(),Name="Third",Hotkey=new(9,51) };
            blocked=third.Hotkey;
            try { bindings.Apply([second,third]); throw new Exception("Conflict accepted"); } catch(InvalidOperationException) { }
            Check(registrations.Count==1 && registrations.ContainsKey(originalId) && bindings.Find(originalId)==workspace.Id,"registration conflict rolls back additions and preserves old shortcut");
            blocked=null; bindings.Apply([second]);
            Check(registrations.Count==1 && !registrations.ContainsKey(originalId) && registrations.Single().Value==second.Hotkey,"successful change releases old shortcut");
            int secondId=registrations.Single().Key;
            bindings.Apply([workspace with { Hotkey=second.Hotkey }]);
            Check(bindings.Find(secondId)==workspace.Id,"existing key transfers ownership without re-registering");
            bindings.Apply([]);
            Check(registrations.Count==0 && bindings.Find(secondId)==null,"deletion unregisters and ignores queued stale messages");
            bindings.Apply([workspace]);
            var undo=bindings.Change(second);
            Check(registrations.Count==2,"editing one Workspace retains other registered shortcuts");
            undo();
            Check(registrations.Count==1 && registrations.Single().Value==workspace.Hotkey,"failed durable save can roll back just the registration change");
            bindings.RemoveWorkspace(workspace.Id);
            Check(registrations.Count==0,"deleting Workspace releases key independently of other conflicts");
            bindings.Apply([workspace]);
        }
        Check(registrations.Count==0,"shutdown unregisters all shortcuts");
        var document=new WorkspaceDocument(2,0,workspace.Id,[workspace]);
        var path=Path.Combine(Path.GetTempPath(),"findowgrid-p5-"+Guid.NewGuid(),"workspaces.json");
        try
        {
            var store=new WorkspaceStore(path); store.Save(document,0); var loaded=store.Load();
            Check(loaded.Workspaces[0].Hotkey==hotkey && loaded.LastWorkspaceId==workspace.Id,"shortcut and last Workspace persist");
            Check(loaded.Workspaces[0].Windows[0].Snapshot.Monitor.DevicePath==primary.DevicePath,"monitor identity persists");
            var duplicate=workspace with { Id=Guid.NewGuid(),Name="Macro" };
            try { WorkspaceStore.Validate(document with { Workspaces=[workspace,duplicate] }); throw new Exception("Duplicate shortcut accepted"); } catch(InvalidDataException) { count++; }
            var updated=WorkspaceEdits.Upsert(document,workspace with { Name="Renamed" });
            Check(updated.Workspaces[0].Hotkey==hotkey,"rename preserves shortcut");
            Check(WorkspaceEdits.Clone(workspace).Hotkey==hotkey,"edit draft preserves shortcut");
            store.Save(loaded with { Workspaces=[workspace with { Hotkey=null }] },loaded.Revision);
            Check(store.Load().Workspaces[0].Hotkey==null,"removing shortcut persists without stale assignment");
        }
        finally { if(Directory.Exists(Path.GetDirectoryName(path))) Directory.Delete(Path.GetDirectoryName(path)!,true); }
        return count;
    }
}
