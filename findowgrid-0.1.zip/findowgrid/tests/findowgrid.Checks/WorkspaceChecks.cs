using System.Text.Json;
using findowgrid.Engine.Models;
using findowgrid.Engine.Services;
using findowgrid.Engine.Storage;

internal static class WorkspaceChecks
{
    public static async Task<int> Run()
    {
        int count=0;
        void Check(bool ok,string name) { if(!ok) throw new Exception("FAIL: "+name); Console.WriteLine("PASS: "+name); count++; }
        var monitor=new MonitorSnapshot("DISPLAY1",new(0,0,1920,1080),new(0,0,1920,1040),true);
        WindowInfo Window(int id,string title)=>new((nint)id,(uint)(id+100),id*1000,
            new("app","C:\\App\\app.exe","AppClass",title),new(20,30,800,600),new(20,30,800,600),WindowState.Normal,false,monitor,96,null);
        var a=Window(1,"FX" ); var b=Window(2,"Macro"); var shared=Window(3,"Research"); var unmanaged=Window(4,"Personal");
        var fake=new FakeDesktop([a,b,shared,unmanaged]);
        var service=new WorkspaceService(fake);
        var ca=service.Capture("FX",[a,shared]); service.Remember(ca);
        var cb=service.Capture("Macro",[b,shared]); service.Remember(cb);
        var all=new[]{ca.Workspace,cb.Workspace};
        var result=await service.OpenAsync(ca.Workspace,all);
        Check(result.Completed && fake.Restored.SetEquals([a.Handle,shared.Handle]),"Workspace restores all target windows");
        Check(fake.Minimized.SetEquals([b.Handle]),"only another registered Workspace window is minimized");
        Check(!fake.Restored.Contains(unmanaged.Handle) && !fake.Minimized.Contains(unmanaged.Handle),"unmanaged window untouched");
        Check(!fake.Minimized.Contains(shared.Handle),"shared window protected from minimization");
        Check(fake.Events.Last().StartsWith("min:"),"target restoration precedes minimization");
        fake.ClearCalls();
        result=await service.OpenAsync(cb.Workspace,all);
        Check(result.Completed && fake.Restored.SetEquals([b.Handle,shared.Handle]) && fake.Minimized.SetEquals([a.Handle]),"A to B switch restores minimized target and minimizes A");

        fake=new FakeDesktop([a,b,shared,unmanaged]);
        service=new WorkspaceService(fake);
        result=await service.OpenAsync(ca.Workspace,all);
        Check(result.Completed && fake.Restored.SetEquals([a.Handle,shared.Handle]),"restart without bindings uses unique exact identity");
        fake=new FakeDesktop([a,shared,unmanaged]); service=new(fake);
        result=await service.OpenAsync(cb.Workspace,all);
        Check(!result.Completed && fake.Minimized.Count==0 && !fake.Restored.Contains(a.Handle),"missing target prevents other Workspace minimization");

        fake=new FakeDesktop([a,b,shared]); fake.FailRestore.Add(a.Handle); service=new(fake);
        result=await service.OpenAsync(ca.Workspace,all);
        Check(!result.Completed && fake.Minimized.Count==0,"failed restore prevents minimization");
        fake=new FakeDesktop([a,b,shared]); fake.PartialRestore.Add(a.Handle); service=new(fake);
        result=await service.OpenAsync(ca.Workspace,all);
        Check(!result.Completed && fake.Minimized.Count==0,"partial restore prevents minimization");

        var duplicate=Window(5,"FX");
        fake=new FakeDesktop([a,duplicate,b,shared]); service=new(fake);
        result=await service.OpenAsync(ca.Workspace,all);
        Check(!result.Completed && !fake.Restored.Contains(a.Handle) && !fake.Restored.Contains(duplicate.Handle) && fake.Minimized.Count==0,"ambiguous exact candidates are never moved");
        var duplicateEntries=ca.Workspace with { Id=Guid.NewGuid(),Name="Collision",Windows=[ca.Workspace.Windows[0],ca.Workspace.Windows[0] with { Id=Guid.NewGuid() }] };
        fake=new FakeDesktop([a,b]); service=new(fake);
        result=await service.OpenAsync(duplicateEntries,[duplicateEntries,cb.Workspace]);
        Check(!result.Completed && fake.Restored.Count==0 && fake.Minimized.Count==0,"one HWND cannot satisfy two saved entries");

        fake=new FakeDesktop([a,b,shared]); service=new(fake); service.Remember(ca);
        fake.Live[0]=a with { Identity=a.Identity with { Title="FX - changed live title" } };
        result=await service.OpenAsync(ca.Workspace,all);
        Check(result.Completed && fake.Restored.Contains(a.Handle),"live binding survives title changes");
        fake=new FakeDesktop([a with { ProcessId=999,ProcessStartTicks=999,Identity=a.Identity with { Title="Unrelated" } },b,shared]);
        service=new(fake); service.Remember(ca);
        result=await service.OpenAsync(ca.Workspace,all);
        Check(!result.Completed && !fake.Restored.Contains(a.Handle) && fake.Minimized.Count==0,"reused HWND with different process lifetime rejected");
        var noPath=a with { Identity=a.Identity with { ExecutablePath=null } };
        fake=new FakeDesktop([noPath]); service=new(fake); var cp=service.Capture("No path",[noPath]);
        result=await service.OpenAsync(cp.Workspace,[cp.Workspace]);
        Check(!result.Completed && fake.Restored.Count==0,"missing executable path does not permit weak restart matching");
        service.Remember(cp); result=await service.OpenAsync(cp.Workspace,[cp.Workspace]);
        Check(result.Completed,"explicit current-session binding supports inaccessible path");

        fake=new FakeDesktop([a,b,shared]); service=new(fake);
        var cc=service.Capture("Third",[b]);
        result=await service.OpenAsync(ca.Workspace,[ca.Workspace,cb.Workspace,cc.Workspace]);
        Check(result.Completed && fake.Events.Count(e=>e==$"min:{b.Handle}")==1,"other shared window minimized once");

        fake=new FakeDesktop([a]); service=new(fake); var single=service.Capture("Single",[a]);
        fake.Block=new(TaskCreationOptions.RunContinuationsAsynchronously);
        var first=service.OpenAsync(single.Workspace,[single.Workspace]);
        await fake.Entered.Task;
        var second=await service.OpenAsync(single.Workspace,[single.Workspace]);
        fake.Block.SetResult(true); await first;
        Check(!second.Completed && fake.Events.Count(e=>e.StartsWith("restore:"))==1,"overlapping switches rejected");

        var folder=Path.Combine(Path.GetTempPath(),"findowgrid-workspace-"+Guid.NewGuid().ToString("N"));
        try
        {
            var path=Path.Combine(folder,"workspaces.json"); var store=new WorkspaceStore(path);
            Check(store.Load().Workspaces.Count==0,"missing Workspace file gives empty collection");
            var doc=store.Save(new(1,0,null,all.ToList()),0);
            var loaded=store.Load();
            Check(loaded.Workspaces.Count==2 && loaded.Workspaces[0].Windows.Count==2 && loaded.Workspaces[0].Windows[0].Snapshot==ca.Workspace.Windows[0].Snapshot,"multiple Workspace JSON roundtrip");
            doc=store.Save(doc with { LastWorkspaceId=cb.Workspace.Id },doc.Revision);
            Check(doc.Revision==2 && store.Load().LastWorkspaceId==cb.Workspace.Id,"last Workspace and revision persisted");
            Check(new WorkspaceStore(path+".bak").Load().Revision==1,"Workspace atomic write keeps backup");
            try { store.Save(loaded,loaded.Revision); throw new Exception("Stale revision accepted"); } catch(InvalidOperationException) { }
            Check(store.Load().Revision==2,"stale writer cannot overwrite newer data");
            string json=File.ReadAllText(path);
            Check(!json.Contains("handle",StringComparison.OrdinalIgnoreCase) && !json.Contains("process_id",StringComparison.OrdinalIgnoreCase),"Workspace JSON contains no HWND or PID");
            try { WorkspaceStore.Validate(doc with { Workspaces=[ca.Workspace,ca.Workspace with { Id=Guid.NewGuid(),Name="fx" }] }); throw new Exception("Duplicate name accepted"); } catch(InvalidDataException) { }
            Check(true,"case-insensitive duplicate names rejected");
            try { WorkspaceStore.Validate(doc with { LastWorkspaceId=Guid.NewGuid() }); throw new Exception("Unknown last workspace accepted"); } catch(InvalidDataException) { }
            Check(true,"dangling last Workspace rejected");
            try { WorkspaceStore.Validate(doc with { Workspaces=[ca.Workspace with { Windows=[] }] }); throw new Exception("Empty workspace accepted"); } catch(InvalidDataException) { }
            Check(true,"empty Workspace rejected");
            File.WriteAllText(path,"{bad");
            try { store.Save(doc,doc.Revision); throw new Exception("Corruption overwritten"); } catch(JsonException) { }
            Check(File.ReadAllText(path)=="{bad","corrupt Workspace file never overwritten by save");
        }
        finally { if(Directory.Exists(folder)) Directory.Delete(folder,true); }
        return count;
    }
}
internal sealed class FakeDesktop(List<WindowInfo> windows) : IWindowDesktop
{
    public List<WindowInfo> Live { get; }=windows;
    public HashSet<nint> Restored { get; }=[];
    public HashSet<nint> Minimized { get; }=[];
    public HashSet<nint> FailRestore { get; }=[];
    public HashSet<nint> PartialRestore { get; }=[];
    public List<string> Events { get; }=[];
    public TaskCompletionSource<bool>? Block { get; set; }
    public TaskCompletionSource<bool> Entered { get; }=new(TaskCreationOptions.RunContinuationsAsynchronously);
    private readonly object sync=new();
    public IReadOnlyList<WindowInfo> Enumerate()=>Live.ToArray();
    public WindowSnapshot Capture(WindowInfo w)=>new(1,DateTimeOffset.UtcNow,w.Identity,w.NormalBoundsScreenPx,w.State,w.RestoreToMaximized,w.Monitor,w.WindowDpi,w.VisibleBoundsPx);
    public async Task<WindowOperationResult> RestoreAsync(WindowInfo w,WindowSnapshot snapshot)
    {
        lock(sync) { Restored.Add(w.Handle); Events.Add($"restore:{w.Handle}"); }
        Entered.TrySetResult(true);
        if(Block!=null) await Block.Task;
        if(FailRestore.Contains(w.Handle)) return new(OperationStatus.Failed,"simulated failure");
        if(PartialRestore.Contains(w.Handle)) return new(OperationStatus.Partial,"simulated partial");
        lock(sync)
        {
            int i=Live.FindIndex(x=>x.Handle==w.Handle);
            Live[i]=Live[i] with { State=snapshot.State,NormalBoundsScreenPx=snapshot.NormalBoundsScreenPx };
        }
        return new(OperationStatus.Success,"restored");
    }
    public Task<WindowOperationResult> MinimizeAsync(WindowInfo w)
    {
        Minimized.Add(w.Handle); Events.Add($"min:{w.Handle}");
        int i=Live.FindIndex(x=>x.Handle==w.Handle); Live[i]=Live[i] with { State=WindowState.Minimized };
        return Task.FromResult(new WindowOperationResult(OperationStatus.Success,"minimized"));
    }
    public void ClearCalls() { Restored.Clear(); Minimized.Clear(); Events.Clear(); }
}
