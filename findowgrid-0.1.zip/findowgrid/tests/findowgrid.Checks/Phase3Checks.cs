using System.Text.Json;
using System.Text.Json.Serialization;
using findowgrid.Engine.Models;
using findowgrid.Engine.Services;
using findowgrid.Engine.Storage;
internal static class Phase3Checks
{
    public static async Task<int> Run()
    {
        int count=0;
        void Check(bool ok,string name) { if(!ok) throw new Exception("FAIL: "+name); Console.WriteLine("PASS: "+name); count++; }
        var area=new PixelRect(0,0,1920,1040);
        var outer=new PixelRect(953,0,974,1047); var visible=new PixelRect(960,0,960,1040);
        var inset=PlacementGeometry.Insets(outer,visible);
        Check(inset==new FrameInsets(7,0,7,7),"DWM invisible frame margins measured");
        Check(PlacementGeometry.OuterFromVisible(visible,inset)==outer,"right-snapped visible bounds convert back to exact outer bounds");
        Check(PlacementGeometry.MapOuter(outer,area,area,inset)==outer,"right-edge invisible border is not incorrectly clamped inward");
        var fullOuter=new PixelRect(-7,0,1934,1047);
        Check(PlacementGeometry.MapOuter(fullOuter,area,area,inset)==fullOuter,"full-width window retains both invisible side borders");
        var leftArea=new PixelRect(-1920,0,1920,1040);
        var leftVisible=new PixelRect(-960,0,960,1040);
        Check(PlacementGeometry.VisibleFromOuter(PlacementGeometry.MapOuter(new(-967,0,974,1047),leftArea,leftArea,inset),inset)==leftVisible,"negative monitor edge alignment retained");
        var dpiInset=new FrameInsets(11,0,11,11);
        var dest=new PixelRect(1920,0,2560,1400);
        var mapped=PlacementGeometry.Map(visible,area,dest);
        Check(PlacementGeometry.VisibleFromOuter(PlacementGeometry.OuterFromVisible(mapped,dpiInset),dpiInset)==new PixelRect(3200,0,1280,1400),"destination DPI margins do not create edge gaps");
        var repeated=outer;
        for(int i=0;i<100;i++) repeated=PlacementGeometry.MapOuter(repeated,area,area,inset);
        Check(repeated==outer,"100 repeated edge mappings do not drift");
        Check(PlacementGeometry.Insets(outer,new(-1000,-1000,8000,8000))==FrameInsets.Zero,"invalid DWM frame margins rejected");

        var monitor=new MonitorSnapshot("DISPLAY1",new(0,0,1920,1080),area,true);
        WindowInfo Window(int id,string title)=>new((nint)id,(uint)(id+100),id*1000,
            new("app","C:\\App\\app.exe","AppClass",title),outer,outer,WindowState.Normal,false,monitor,96,null,visible);
        var initial=Window(10,"TradingView EURUSD");
        var snapshot=new WindowSnapshot(1,DateTimeOffset.UtcNow,initial.Identity,outer,WindowState.Normal,false,monitor,96,visible);
        var entry=new WorkspaceWindow(Guid.NewGuid(),snapshot,new(LaunchKind.Application,initial.Identity.ExecutablePath,WaitSeconds:1));
        var changed=Window(11,"TradingView USDKRW");
        Check(WindowMatcher.Resolve(entry,null,[changed]).Window==null,"unconfigured changed title does not guess a target");
        var patterned=entry with { Match=new("TradingView") };
        Check(WindowMatcher.Resolve(patterned,null,[changed]).Window==changed,"explicit title pattern identifies a changed market title");
        Check(WindowMatcher.Resolve(patterned,null,[changed,Window(12,"TradingView GBPUSD")]).Status==MatchStatus.Ambiguous,"two matching title patterns remain ambiguous");
        Check(WindowMatcher.Resolve(entry,null,[initial with { Identity=initial.Identity with { ExecutablePath="C:\\Other\\app.exe" } }]).Window==null,"strong path mismatch cannot be outweighed by title");
        Check(WindowMatcher.Resolve(entry,null,[initial with { Identity=initial.Identity with { ClassName="OtherClass" } }]).Window==null,"class mismatch rejected");
        Check(WindowMatcher.Resolve(entry,null,[initial with { Identity=initial.Identity with { Title="* TradingView   EURUSD" } }]).Window!=null,"minor dirty marker and whitespace title normalization");
        Check(WindowMatcher.Resolve(entry,null,[initial],new HashSet<nint>{initial.Handle}).Window==null,"already claimed window excluded");
        var newMain=Window(20,"Welcome");
        Check(WindowMatcher.Resolve(entry,null,[newMain],launch:new([],new(newMain.ProcessId,"started"))).Window==newMain,"fresh window from launched process may change initial title");
        Check(WindowMatcher.Resolve(entry,null,[newMain],launch:new([],new(999,"started"))).Window==null,"unrelated new process is not accepted with a different title");
        Check(WindowMatcher.Resolve(entry,null,[initial],launch:new([initial],new(null,"singleton"))).Window==null,"unchanged prelaunch candidate is not falsely attributed to launch");
        var oldTab=initial with { Identity=initial.Identity with { Title="Old tab" } };
        Check(WindowMatcher.Resolve(entry,null,[initial],launch:new([oldTab],new(null,"URL"))).Window==initial,"singleton browser title change can establish URL target");

        var fake=new FakeDesktop([]);
        int launches=0;
        var launcher=new TestLauncher(_=>{ launches++; fake.Live.Add(newMain); return new(newMain.ProcessId,"started"); });
        var coordinator=new WindowLaunchCoordinator(fake,launcher,TimeSpan.FromMilliseconds(5));
        var found=await coordinator.LaunchAndWaitAsync(Guid.NewGuid(),entry,new HashSet<nint>(),CancellationToken.None);
        Check(found.Window==newMain && launches==1,"missing app launched once and stable new window found");
        fake=new FakeDesktop([initial]); launches=0;
        coordinator=new(fake,new TestLauncher(_=>{ launches++; return new(null,"unexpected"); }),TimeSpan.FromMilliseconds(5));
        found=await coordinator.LaunchAndWaitAsync(Guid.NewGuid(),entry,new HashSet<nint>(),CancellationToken.None);
        Check(found.Window==initial && launches==0,"late existing match reused without launching");
        fake=new FakeDesktop([]); launches=0; var workspaceId=Guid.NewGuid();
        coordinator=new(fake,new TestLauncher(_=>{ launches++; return new(null,"no window"); }),TimeSpan.FromMilliseconds(5));
        found=await coordinator.LaunchAndWaitAsync(workspaceId,entry,new HashSet<nint>(),CancellationToken.None);
        Check(found.Window==null && launches==1,"window timeout does not relaunch");
        await coordinator.LaunchAndWaitAsync(workspaceId,entry,new HashSet<nint>(),CancellationToken.None);
        Check(launches==1,"cooldown blocks rapid repeated launch requests");
        fake=new FakeDesktop([]); launches=0;
        coordinator=new(fake,new TestLauncher(_=>{ launches++; return new(null,"none"); }),TimeSpan.FromMilliseconds(5));
        await coordinator.LaunchAndWaitAsync(Guid.NewGuid(),entry with { Launch=entry.Launch! with { Behavior=LaunchBehavior.ReuseOnly } },new HashSet<nint>(),CancellationToken.None);
        Check(launches==0,"reuse-only setting never launches");
        using(var cancel=new CancellationTokenSource())
        {
            coordinator=new(fake,new TestLauncher(_=>{ cancel.Cancel(); return new(null,"started"); }),TimeSpan.FromMilliseconds(5));
            try { await coordinator.LaunchAndWaitAsync(Guid.NewGuid(),entry,new HashSet<nint>(),cancel.Token); throw new Exception("Cancellation ignored"); }
            catch(OperationCanceledException) { }
            Check(true,"launch waiting honors cancellation");
        }
        fake=new FakeDesktop([]); launches=0;
        launcher=new(_=>{ launches++; fake.Live.Add(newMain); return new(newMain.ProcessId,"started"); });
        var service=new WorkspaceService(fake,launcher);
        var ws=new Workspace(Guid.NewGuid(),"Launch test",DateTimeOffset.UtcNow,[entry]);
        var report=await service.OpenAsync(ws,[ws]);
        Check(report.Completed && launches==1 && fake.Restored.Contains(newMain.Handle),"full missing-app launch to placement pipeline");
        fake=new FakeDesktop([initial]); launches=0;
        launcher=new(_=>{ launches++; return new(null,"unexpected"); });
        service=new(fake,launcher);
        var duplicate=ws with { Windows=[entry,entry with { Id=Guid.NewGuid() }] };
        report=await service.OpenAsync(duplicate,[duplicate]);
        Check(!report.Completed && launches==0 && fake.Restored.Count==0,"conflicting saved entries cannot trigger a false reuse or extra launch");

        fake=new FakeDesktop([initial]); bool existingMovedAtLaunch=false;
        var missing=entry with { Id=Guid.NewGuid(),Snapshot=snapshot with { Identity=snapshot.Identity with { Title="Second window" } } };
        var secondWindow=Window(30,"Second window");
        launcher=new(_=>{ existingMovedAtLaunch=fake.Restored.Contains(initial.Handle); fake.Live.Add(secondWindow); return new(secondWindow.ProcessId,"started"); });
        service=new(fake,launcher);
        var mixed=ws with { Windows=[entry,missing] };
        report=await service.OpenAsync(mixed,[mixed]);
        Check(report.Completed && existingMovedAtLaunch,"already-open window restoration starts before missing app launch waits");

        void Invalid(LaunchSpec spec,string label)
        { try { LaunchValidation.Validate(spec); throw new Exception("Invalid launch accepted"); } catch(InvalidDataException) { } Check(true,label); }
        Invalid(new(LaunchKind.Url,Url:"javascript:alert(1)"),"non-web URL schemes rejected");
        Invalid(new(LaunchKind.Application,"app.exe"),"relative executable path rejected");
        Invalid(new(LaunchKind.Application,"C:\\test.bat"),"script path rejected");
        Invalid(new(LaunchKind.Application,"C:\\app.exe",WaitSeconds:0),"unbounded or zero wait rejected");
        LaunchValidation.Validate(new(LaunchKind.Url,Url:"https://example.com/calendar",BrowserPath:"C:\\Browser\\browser.exe"));
        Check(true,"explicit browser and HTTPS URL configuration accepted");

        var folder=Path.Combine(Path.GetTempPath(),"findowgrid-phase3-"+Guid.NewGuid().ToString("N")); Directory.CreateDirectory(folder);
        try
        {
            var legacy=Path.Combine(folder,"StockZone","workspaces.json"); Directory.CreateDirectory(Path.GetDirectoryName(legacy)!);
            var prior=ws with { Windows=[entry with { Launch=null,Match=null,Snapshot=snapshot with { VisibleBoundsPx=null } }] };
            var options=new JsonSerializerOptions { PropertyNamingPolicy=JsonNamingPolicy.SnakeCaseLower,Converters={new JsonStringEnumConverter()} };
            File.WriteAllText(legacy,JsonSerializer.Serialize(new WorkspaceDocument(1,7,prior.Id,[prior]),options));
            string original=File.ReadAllText(legacy);
            var path=Path.Combine(folder,"findowgrid","workspaces.json"); var store=new WorkspaceStore(path,legacy);
            var doc=store.Load();
            Check(doc.SchemaVersion==2 && doc.Revision==7 && doc.Workspaces[0].Windows[0].Launch?.Kind==LaunchKind.Application,"legacy StockZone schema migrates in memory with launch defaults");
            Check(File.ReadAllText(legacy)==original && !File.Exists(path),"loading legacy data leaves original untouched");
            var saved=store.Save(doc,doc.Revision);
            Check(File.Exists(path) && saved.Revision==8 && File.ReadAllText(legacy)==original,"first new save writes findowgrid location without overwriting old data");
            doc=saved with { Workspaces=[ws with { Windows=[patterned] }] };
            saved=store.Save(doc,saved.Revision);
            var loaded=store.Load();
            Check(loaded.Workspaces[0].Windows[0].Snapshot.VisibleBoundsPx==visible && loaded.Workspaces[0].Windows[0].Match?.TitleContains=="TradingView","visible bounds and title rules survive JSON roundtrip");
            File.WriteAllText(path,"{bad");
            try { store.Load(); throw new Exception("Corrupt new file hidden by legacy fallback"); } catch(JsonException) { }
            Check(true,"corrupt new data does not silently fall back to stale legacy file");
        }
        finally { Directory.Delete(folder,true); }
        return count;
    }
}
internal sealed class TestLauncher(Func<LaunchSpec,LaunchTicket> action) : IWindowLauncher
{
    public Task<LaunchTicket> LaunchAsync(LaunchSpec spec,CancellationToken cancellationToken)
    { cancellationToken.ThrowIfCancellationRequested(); return Task.FromResult(action(spec)); }
}
