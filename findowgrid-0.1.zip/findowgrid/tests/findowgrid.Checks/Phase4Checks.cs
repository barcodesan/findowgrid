using findowgrid.Engine.Models;
using findowgrid.Engine.Services;
using findowgrid.Engine.Storage;
internal static class Phase4Checks
{
    public static async Task<int> Run()
    {
        int count=0;
        void Check(bool value,string name) { if(!value) throw new Exception("FAIL: "+name); Console.WriteLine("PASS: "+name); count++; }
        var monitor=new MonitorSnapshot("DISPLAY1",new(0,0,1920,1080),new(0,0,1920,1040),true);
        WindowInfo Window(int id,string title)=>new((nint)id,(uint)(id+100),id*1000,
            new("app","C:\\App\\app.exe","AppClass",title),new(20,30,800,600),new(20,30,800,600),WindowState.Normal,false,monitor,96,null,new(27,30,786,593));
        var a=Window(1,"FX"); var b=Window(2,"News"); var c=Window(3,"Unmanaged");
        var fake=new FakeDesktop([a,b,c]); var service=new WorkspaceService(fake);
        var captured=service.Capture("FX",[a,b]); service.Remember(captured);
        var workspace=captured.Workspace;
        var original=workspace.Windows[0] with { Launch=new(LaunchKind.Url,Url:"https://example.com",Arguments:["--flag"]),Match=new("FX market") };
        workspace=workspace with { Windows=[original,workspace.Windows[1]] };
        var draft=new WorkspaceDraft(workspace,new Dictionary<Guid,WindowInfo>());
        var clone=WorkspaceEdits.Clone(workspace);
        clone.Windows[0].Launch!.Arguments![0]="changed";
        Check(workspace.Windows[0].Launch!.Arguments![0]=="--flag","edit draft deep-copies mutable launch arguments");
        var other=service.Capture("Macro",[c]).Workspace;
        var document=new WorkspaceDocument(2,4,workspace.Id,[workspace,other]);
        var renamed=WorkspaceEdits.Upsert(document,workspace with { Name="  FX Desk  " });
        Check(renamed.Workspaces.Count==2 && renamed.Workspaces[0].Id==workspace.Id && renamed.Workspaces[0].Name=="FX Desk","rename preserves Workspace identity and trims name");
        Check(renamed.LastWorkspaceId==workspace.Id && renamed.Workspaces[1]==other,"rename preserves last Workspace and unrelated entries");
        Check(document.Workspaces[0].Name=="FX","uncommitted edit does not mutate original document");
        try { WorkspaceEdits.Upsert(document,workspace with { Name="macro" }); throw new Exception("Duplicate accepted"); } catch(InvalidDataException) { }
        Check(true,"duplicate edited name rejected");
        try { WorkspaceEdits.Upsert(document,workspace with { Windows=[] }); throw new Exception("Empty accepted"); } catch(InvalidDataException) { }
        Check(true,"empty edited Workspace cannot be persisted");
        var deleted=WorkspaceEdits.Delete(document,workspace.Id);
        Check(deleted.Workspaces.Count==1 && deleted.LastWorkspaceId==null && document.Workspaces.Count==2,"delete clears dangling last ID without mutating original");
        Check(WorkspaceEdits.Delete(document,other.Id).LastWorkspaceId==workspace.Id,"deleting another Workspace keeps last ID");
        try { WorkspaceEdits.Delete(document,Guid.NewGuid()); throw new Exception("Unknown delete accepted"); } catch(InvalidOperationException) { }
        Check(true,"unknown delete cannot silently succeed");
        var withBindings=WorkspaceDraft.FromCapture(captured);
        var removed=WorkspaceEdits.Remove(withBindings,captured.Workspace.Windows[0].Id);
        Check(removed.Workspace.Windows.Count==1 && removed.Bindings.Count==1 && withBindings.Workspace.Windows.Count==2,"remove only affects draft membership and corresponding transient binding");

        var moved=new PixelRect(1000,50,900,900); var visible=new PixelRect(1007,50,886,893);
        fake.Live[0]=a with { NormalBoundsScreenPx=moved,OuterBoundsPx=moved,VisibleBoundsPx=visible };
        var updated=service.CaptureCurrentLayout(draft);
        Check(updated.Succeeded && updated.Draft!.Workspace.Id==workspace.Id && updated.Draft.Workspace.Windows[0].Id==original.Id,"current-screen update preserves Workspace and window IDs");
        Check(updated.Draft!.Workspace.Windows[0].Snapshot.NormalBoundsScreenPx==moved && updated.Draft.Workspace.Windows[0].Snapshot.VisibleBoundsPx==visible,"current-screen update captures new placement including visible frame");
        Check(updated.Draft.Workspace.Windows[0].Launch==original.Launch && updated.Draft.Workspace.Windows[0].Match==original.Match,"layout update preserves URL, arguments and title rules");
        Check(workspace.Windows[0].Snapshot.NormalBoundsScreenPx==a.NormalBoundsScreenPx,"update remains a draft until saved");
        Check(fake.Restored.Count==0 && fake.Minimized.Count==0,"updating layout never moves or minimizes windows");
        Check(updated.Draft.Workspace.Windows.Count==2,"update never captures unmanaged windows implicitly");
        fake.Live.RemoveAll(w=>w.Handle==b.Handle);
        var missing=service.CaptureCurrentLayout(draft);
        Check(!missing.Succeeded && missing.Draft==null && workspace.Windows.Count==2,"missing window aborts the entire update and keeps saved members");
        fake.Live.Add(b);
        var faults=new CaptureFaultDesktop(fake,b.Handle);
        var failed=new WorkspaceService(faults).CaptureCurrentLayout(new(captured.Workspace,new Dictionary<Guid,WindowInfo>()));
        Check(!failed.Succeeded && captured.Workspace.Windows[0].Snapshot.NormalBoundsScreenPx==a.NormalBoundsScreenPx,"capture failure cannot partially overwrite layout");
        var ambiguous=new FakeDesktop([a,a with { Handle=(nint)99,ProcessId=999 },b]);
        Check(!new WorkspaceService(ambiguous).CaptureCurrentLayout(new(captured.Workspace,new Dictionary<Guid,WindowInfo>())).Succeeded,"ambiguous current window blocks update");
        try { service.AddWindows(draft,[fake.Live.First(w=>w.Handle==a.Handle)]); throw new Exception("Duplicate added"); } catch(InvalidOperationException) { }
        Check(true,"adding an already registered live window is rejected");
        var added=service.AddWindows(draft,[c]);
        Check(added.Workspace.Id==workspace.Id && added.Workspace.Windows.Count==3 && workspace.Windows.Count==2,"add appends a captured window only to draft");
        fake.Live[fake.Live.FindIndex(w=>w.Handle==c.Handle)]=c with { Identity=c.Identity with { Title="Changed new title" } };
        Check(service.CaptureCurrentLayout(added).Succeeded,"unsaved added window can be updated through draft-only binding");
        Check(added.Workspace.Windows[0].Launch==original.Launch,"adding a window preserves existing launch settings");
        try { service.AddWindows(draft,[c,c]); throw new Exception("Duplicate handles added"); } catch(ArgumentException) { }
        Check(true,"duplicate selections are rejected before draft mutation");
        service.ForgetWorkspace(workspace.Id);
        fake.Live[0]=fake.Live[0] with { Identity=a.Identity with { Title="No longer matching" } };
        var report=await service.OpenAsync(captured.Workspace,[captured.Workspace]);
        Check(!report.Completed && !fake.Restored.Contains(a.Handle),"forgetting deleted Workspace removes its cached live binding");

        var scene=WorkspacePreviewLayout.Build(captured.Workspace,280,150);
        Check(scene.Monitors.Count==1 && scene.Windows.Count==2,"preview deduplicates monitor frames and includes registered windows");
        bool Fits(PreviewRect r)=>r.X>=0 && r.Y>=0 && r.X+r.Width<=280.0001 && r.Y+r.Height<=150.0001;
        Check(scene.Monitors.All(m=>Fits(m.Bounds)) && scene.Windows.All(w=>Fits(w.Bounds)),"preview geometry fits its viewport");
        var frame=scene.Monitors[0].Bounds;
        Check(Math.Abs(frame.Width/frame.Height-1920.0/1080)<0.0001,"preview keeps monitor aspect ratio");
        var leftMonitor=monitor with { DeviceName="DISPLAY2",Bounds=new(-1920,0,1920,1080),WorkArea=new(-1920,0,1920,1040),IsPrimary=false };
        var leftEntry=captured.Workspace.Windows[0] with { Id=Guid.NewGuid(),Snapshot=captured.Workspace.Windows[0].Snapshot with { Monitor=leftMonitor,NormalBoundsScreenPx=new(-1900,20,800,600),VisibleBoundsPx=null } };
        var dual=captured.Workspace with { Windows=[leftEntry,captured.Workspace.Windows[1]] };
        scene=WorkspacePreviewLayout.Build(dual,280,150);
        Check(scene.Monitors.Count==2 && scene.Monitors[0].Bounds.X<scene.Monitors[1].Bounds.X && scene.Windows.All(w=>Fits(w.Bounds)),"negative-coordinate monitor stays left in preview");
        var mini=captured.Workspace with { Windows=[captured.Workspace.Windows[0] with { Snapshot=captured.Workspace.Windows[0].Snapshot with { State=WindowState.Minimized,RestoreToMaximized=true } }] };
        scene=WorkspacePreviewLayout.Build(mini,280,150);
        Check(scene.Windows[0].Minimized && scene.Windows[0].Bounds.Width>scene.Monitors[0].Bounds.Width*.99,"minimized-maximized preview uses work area and muted flag");
        Check(WorkspacePreviewLayout.Build(null,280,150).Windows.Count==0 && WorkspacePreviewLayout.Build(workspace,0,150).Monitors.Count==0,"empty or zero-size preview is safe");
        var offscreen=captured.Workspace with { Windows=[captured.Workspace.Windows[0] with { Snapshot=captured.Workspace.Windows[0].Snapshot with { VisibleBoundsPx=new(10000,10000,100,100) } }] };
        Check(WorkspacePreviewLayout.Build(offscreen,280,150).Windows.Count==0,"offscreen legacy rectangle cannot spill outside preview");
        var path=Path.Combine(Path.GetTempPath(),"findowgrid-phase4-"+Guid.NewGuid().ToString("N"),"workspaces.json");
        try
        {
            var store=new WorkspaceStore(path);
            var saved=store.Save(WorkspaceEdits.Upsert(WorkspaceDocument.Empty,updated.Draft.Workspace),0);
            Check(store.Load().Workspaces[0].Windows[0].Snapshot.VisibleBoundsPx==visible,"updated visible frame persists through save/load");
            saved=store.Save(WorkspaceEdits.Delete(saved,workspace.Id),saved.Revision);
            Check(store.Load().Workspaces.Count==0,"deleting final Workspace leaves a valid empty document");
        }
        finally { Directory.Delete(Path.GetDirectoryName(path)!,true); }
        return count;
    }
}
internal sealed class CaptureFaultDesktop(IWindowDesktop inner,nint fail) : IWindowDesktop
{
    public IReadOnlyList<WindowInfo> Enumerate()=>inner.Enumerate();
    public WindowSnapshot Capture(WindowInfo window)=>window.Handle==fail ? throw new InvalidOperationException("simulated capture failure") : inner.Capture(window);
    public Task<WindowOperationResult> RestoreAsync(WindowInfo window,WindowSnapshot snapshot)=>throw new Exception("update must not restore");
    public Task<WindowOperationResult> MinimizeAsync(WindowInfo window)=>throw new Exception("update must not minimize");
}
