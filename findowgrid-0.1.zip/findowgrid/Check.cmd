@echo off
setlocal
cd /d "%~dp0"
dotnet build findowgrid.slnx -c Release
if errorlevel 1 goto failed
dotnet run --project tests\findowgrid.Checks\findowgrid.Checks.csproj -c Release --no-build
if errorlevel 1 goto failed
echo Build and non-native checks passed.
pause
exit /b 0
:failed
echo Checks failed. Review the output above.
pause
exit /b 1
