# 0.5.1 검증 (Chrome 독립 창 복원)

- .NET SDK 10.0.401 / WindowsDesktop targeting pack 10.0.12, Linux에서 Windows 대상 교차 빌드.
- Release 빌드: 오류 0, 경고 0.
- 자동 검사: 172개 통과. 기존 140개 회귀 + Chrome 복원 32개.
- Phase 5: 모니터 장치 식별·화면 번호/해상도 변경·분리/모호성/legacy fallback, 단축키 유효성·JSON 저장/제거·중복 방지, 등록 실패 rollback·기존 키 보존·등록 소유권 변경·삭제/종료 해제·오래된 메시지 무시.
- 네이티브 등록 자체는 테스트 대역을 이용했습니다. 실제 RegisterHotKey, NotifyIcon, 로그인 자동 실행, 다중 DPI 디스플레이, WPF 렌더링, HTS 동작은 Linux에서 실행하지 않았습니다.
- Windows 실기 검증 항목은 WINDOWS-TEST-CHECKLIST.md. 자동 검사 통과는 실기 성공 보장이 아닙니다.
- 저장 파일 schema 1/2 읽기 호환. Phase 5 추가 필드는 선택 사항입니다. 이전 버전으로 다시 저장하면 새 필드가 사라질 수 있으므로 다운그레이드 전 JSON을 복사해 보관하세요.

참고한 공식 API 문서:
- https://learn.microsoft.com/windows/win32/api/winuser/nf-winuser-enumdisplaydevicesw
- https://learn.microsoft.com/windows/win32/api/winuser/nf-winuser-registerhotkey

## Chrome 수정 검증 범위
- 실제 ProcessStartInfo의 독립 창 인수·URL·프로필 전달, 중복 인수 방지, 기존 기본 브라우저 동작 유지.
- 실행 요청 PID와 실제 Chrome 창 PID가 다른 상황, 기존 창의 탭 제목 변경 거절, 새 창 후보 모호성 거절, 로딩/새 탭 화면 오인 방지.
- 테스트 대역에서 두 개의 저장 항목을 두 개의 새 창으로 복원하고 반복 OPEN에서 재사용하는 흐름 확인.
- URL 없는 닫힌 Chrome은 실행 전 안내하고, 이미 열린 창은 계속 재사용.
- 기존 JSON의 새 필드 누락 호환과 저장 roundtrip.
- 실제 Chrome 실행/종료·프로필 선택·네트워크 로딩·Windows 창 이동은 이 Linux 환경에서 실행하지 않았습니다. WINDOWS-TEST-CHECKLIST.md의 0.5.1 항목을 사용자 Windows에서 확인해야 합니다.
- Chromium 독립 창 옵션 근거: https://chromium.googlesource.com/chromium/src/+/refs/tags/147.0.7727.118/chrome/common/chrome_switches.cc (kOpenInNewWindow).
