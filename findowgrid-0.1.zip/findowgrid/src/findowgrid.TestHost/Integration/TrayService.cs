using findowgrid.Engine.Models;
using Forms=System.Windows.Forms;
namespace findowgrid.TestHost.Integration;
public sealed class TrayService : IDisposable
{
    private readonly Forms.NotifyIcon icon=new() { Icon=System.Drawing.SystemIcons.Application,Text="findowgrid",Visible=true };
    private readonly Action<Guid> open;
    private readonly Action show,exit;
    public TrayService(Action<Guid> open,Action show,Action exit)
    { this.open=open; this.show=show; this.exit=exit; icon.DoubleClick+=(_,_)=>show(); }
    public void Update(WorkspaceDocument document)
    {
        var menu=new Forms.ContextMenuStrip();
        foreach(var workspace in document.Workspaces)
            menu.Items.Add(workspace.Name+(workspace.Hotkey==null?"":"   "+workspace.Hotkey),null,(_,_)=>open(workspace.Id));
        menu.Items.Add(new Forms.ToolStripSeparator());
        var last=menu.Items.Add("Restore Last Workspace",null,(_,_)=> { if(document.LastWorkspaceId is {} id) open(id); });
        last.Enabled=document.LastWorkspaceId!=null;
        menu.Items.Add("Open findowgrid",null,(_,_)=>show());
        menu.Items.Add("Exit",null,(_,_)=>exit());
        var old=icon.ContextMenuStrip; icon.ContextMenuStrip=menu; old?.Dispose();
    }
    public void Notify(string text) { icon.ShowBalloonTip(4000,"findowgrid",text,Forms.ToolTipIcon.Info); }
    public void Dispose() { icon.Visible=false; icon.ContextMenuStrip?.Dispose(); icon.Dispose(); }
}
