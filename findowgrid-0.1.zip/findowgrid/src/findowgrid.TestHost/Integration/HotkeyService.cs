using System.Runtime.InteropServices;
using System.Windows.Interop;
using findowgrid.Engine.Models;
namespace findowgrid.TestHost.Integration;
public sealed class HotkeyService : IDisposable
{
    private readonly HwndSource source;
    private readonly Action<Guid> open;
    private readonly findowgrid.Engine.Services.HotkeyBindings bindings;
    public HotkeyService(nint handle,Action<Guid> open)
    {
        source=HwndSource.FromHwnd(handle); this.open=open;
        bindings=new((id,key)=>RegisterHotKey(source.Handle,id,key.Modifiers|0x4000,key.Key),id=>UnregisterHotKey(source.Handle,id));
        source.AddHook(Hook);
    }
    public void Apply(IEnumerable<Workspace> workspaces)=>bindings.Apply(workspaces);
    public Action Change(Workspace workspace)=>bindings.Change(workspace);
    public void RemoveWorkspace(Guid id)=>bindings.RemoveWorkspace(id);
    private nint Hook(nint hwnd,int message,nint w,nint l,ref bool handled)
    {
        if(message==0x0312)
        { if(bindings.Find((int)w) is {} id) { handled=true; open(id); } }
        return 0;
    }
    public void Dispose() { bindings.Dispose(); source.RemoveHook(Hook); }
    [DllImport("user32.dll",SetLastError=true)] [return:MarshalAs(UnmanagedType.Bool)]
    private static extern bool RegisterHotKey(nint handle,int id,uint modifiers,uint key);
    [DllImport("user32.dll")] [return:MarshalAs(UnmanagedType.Bool)]
    private static extern bool UnregisterHotKey(nint handle,int id);
}
