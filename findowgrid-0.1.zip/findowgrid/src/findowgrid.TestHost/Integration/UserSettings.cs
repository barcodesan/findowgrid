using System.IO;
using System.Text.Json;
using Microsoft.Win32;
namespace findowgrid.TestHost.Integration;
public sealed record UserSettings(bool RestoreLast=false);
public sealed class SettingsStore
{
    private readonly string path=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"findowgrid","settings.json");
    public UserSettings Load() => File.Exists(path)
        ? JsonSerializer.Deserialize<UserSettings>(File.ReadAllText(path)) ?? throw new InvalidDataException("설정 파일이 비어 있습니다.") : new();
    public void Save(UserSettings settings)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        string temp=path+"."+Guid.NewGuid().ToString("N")+".tmp";
        try
        {
            using(var stream=new FileStream(temp,FileMode.CreateNew,FileAccess.Write,FileShare.None))
            { JsonSerializer.Serialize(stream,settings,new JsonSerializerOptions { WriteIndented=true }); stream.Flush(true); }
            if(File.Exists(path)) File.Replace(temp,path,path+".bak"); else File.Move(temp,path);
        }
        finally { if(File.Exists(temp)) File.Delete(temp); }
    }
}
public static class StartupRegistration
{
    private const string Run=@"Software\Microsoft\Windows\CurrentVersion\Run";
    public static string? Read() { using var key=Registry.CurrentUser.OpenSubKey(Run); return key?.GetValue("findowgrid") as string; }
    public static string Command()
    {
        string executable=Environment.ProcessPath ?? throw new InvalidOperationException("실행 경로를 찾을 수 없습니다.");
        string assembly=typeof(StartupRegistration).Assembly.Location;
        return Path.GetFileNameWithoutExtension(executable).Equals("dotnet",StringComparison.OrdinalIgnoreCase)
            ? $"\"{executable}\" \"{assembly}\" --startup" : $"\"{executable}\" --startup";
    }
    public static void Write(string? command)
    { using var key=Registry.CurrentUser.CreateSubKey(Run); if(command==null) key.DeleteValue("findowgrid",false); else key.SetValue("findowgrid",command); }
}
