using System.Windows;
using System.Windows.Interop;
using findowgrid.TestHost.Integration;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using findowgrid.Engine.Models;
using findowgrid.Engine.Services;
using findowgrid.Engine.Storage;
namespace findowgrid.TestHost;
public partial class WorkspaceWindow : Window
{
    private readonly WorkspaceStore store=new();
    private readonly WorkspaceService service=new(new WindowsDesktop(),new WindowLauncher());
    private WorkspaceDocument document=WorkspaceDocument.Empty;
    private bool busy,storageBlocked,exiting,notified,hotkeyWarning;
    private HotkeyService? hotkeys;
    private TrayService? tray;
    private CancellationTokenSource? opening;
    public WorkspaceWindow()
    {
        InitializeComponent();
        SourceInitialized+=(_,_)=>
        {
            hotkeys=new(new WindowInteropHelper(this).Handle,id=>_=OpenWorkspaceAsync(id));
            tray=new(id=>_=OpenWorkspaceAsync(id),ShowMain,RequestExit);
            tray.Update(document);
        };
        Loaded+=async (_,_)=>
        {
            await RunAsync(LoadAsync);
            if(Environment.GetCommandLineArgs().Contains("--startup") && !storageBlocked)
            {
                try
                {
                    bool restore=new SettingsStore().Load().RestoreLast;
                    if(!hotkeyWarning) Hide();
                    if(restore && document.LastWorkspaceId is {} id) await OpenWorkspaceAsync(id);
                }
                catch(Exception ex) { ShowMain(); Status.Text="시작 설정을 읽지 못했습니다: "+ex.Message; }
            }
        };
        Closing+=(_,e)=>
        {
            if(((App)Application.Current).Ending || exiting) return;
            e.Cancel=true;
            if(busy) { Status.Text="작업 중입니다. 복원을 중단하려면 취소를 누르세요."; return; }
            Hide(); if(!notified) { notified=true; tray?.Notify("트레이에서 계속 실행 중입니다. 완전히 종료하려면 Exit를 선택하세요."); }
        };
        Closed+=(_,_)=>PrepareExit();
    }
    private async Task RunAsync(Func<Task> action)
    {
        if(busy) return; busy=true; Root.IsEnabled=false; Progress.Visibility=Visibility.Visible;
        try { await action(); }
        catch(Exception ex) { Status.Text="작업 실패: "+ex.Message; }
        finally { busy=false; Root.IsEnabled=true; Progress.Visibility=Visibility.Collapsed; SaveButton.IsEnabled=!storageBlocked; Cards.IsEnabled=!storageBlocked; if(exiting) Close(); }
    }
    private async Task LoadAsync()
    {
        try
        {
            document=await Task.Run(store.Load); service.ResetBindings(); storageBlocked=false; RenderCards();
            Status.Text=store.LoadedLegacyData ? "기존 Workspace를 불러왔습니다." : "준비되었습니다.";
            hotkeys?.Apply([]); hotkeyWarning=false;
            var accepted=new List<Workspace>();
            foreach(var workspace in document.Workspaces)
            {
                try { hotkeys?.Apply(accepted.Append(workspace)); accepted.Add(workspace); }
                catch(Exception ex) { Status.Text+="\n"+workspace.Name+": "+ex.Message; }
            }
            if(accepted.Count!=document.Workspaces.Count) { hotkeyWarning=true; ShowMain(); tray?.Notify("일부 단축키를 등록하지 못했습니다. Workspace 편집에서 변경하세요."); }
        }
        catch(Exception ex)
        { storageBlocked=true; Status.Text="저장 파일을 읽지 못했습니다. 원본을 보존하고 저장·복원을 중단했습니다. "+ex.Message; }
    }
    private void RenderCards()
    {
        tray?.Update(document);
        Cards.ItemsSource=document.Workspaces.Select(w=>new WorkspaceCard(w,w.Id==document.LastWorkspaceId)).ToArray();
        EmptyState.Visibility=document.Workspaces.Count==0 ? Visibility.Visible : Visibility.Collapsed;
        CountLabel.Text=document.Workspaces.Count==0 ? "원하는 화면을 먼저 배치하세요." : $"{document.Workspaces.Count}개의 저장된 환경";
    }
    private string NextName()
    {
        for(int i=1;;i++)
        { string name=$"Workspace {i}"; if(!document.Workspaces.Any(w=>string.Equals(w.Name,name,StringComparison.OrdinalIgnoreCase))) return name; }
    }
    private async Task SaveDraftAsync(WorkspaceDraft draft)
    {
        var next=WorkspaceEdits.Upsert(document,draft.Workspace);
        var undo=hotkeys?.Change(draft.Workspace);
        try { document=await Task.Run(()=>store.Save(next,document.Revision)); }
        catch { try { undo?.Invoke(); } catch(Exception ex) { Status.Text="단축키 재등록 실패: "+ex.Message; } throw; }
        service.CommitDraftBindings(draft); RenderCards(); Status.Text=$"{draft.Workspace.Name}을 저장했습니다.";
    }
    private async Task DeleteAsync(Guid id)
    {
        var next=WorkspaceEdits.Delete(document,id);
        document=await Task.Run(()=>store.Save(next,document.Revision));
        hotkeys?.RemoveWorkspace(id); service.ForgetWorkspace(id); RenderCards(); Status.Text="Workspace를 삭제했습니다.";
    }
    private async void Save_Click(object sender,RoutedEventArgs e)
    {
        if(storageBlocked) return;
        await RunAsync(async ()=>
        {
            var picker=new WindowPickerWindow { Owner=this };
            if(picker.ShowDialog()!=true) return;
            string name=NextName();
            var captured=await Task.Run(()=>service.Capture(name,picker.SelectedWindows));
            new WorkspaceEditorWindow(WorkspaceDraft.FromCapture(captured),service,SaveDraftAsync) { Owner=this }.ShowDialog();
        });
    }
    private async void Edit_Click(object sender,RoutedEventArgs e)
    {
        if(storageBlocked || sender is not Button { Tag: Workspace workspace }) return;
        await RunAsync(()=>
        {
            new WorkspaceEditorWindow(new(workspace,new Dictionary<Guid,WindowInfo>()),service,SaveDraftAsync,()=>DeleteAsync(workspace.Id)) { Owner=this }.ShowDialog();
            return Task.CompletedTask;
        });
    }
    private async void Open_Click(object sender,RoutedEventArgs e)
    {
        if(sender is Button { Tag: Workspace target }) await OpenWorkspaceAsync(target.Id);
    }
    private async Task OpenWorkspaceAsync(Guid id)
    {
        if(busy || storageBlocked || exiting) { tray?.Notify("현재 작업을 완료한 뒤 다시 실행하세요."); return; }
        var target=document.Workspaces.FirstOrDefault(w=>w.Id==id);
        if(target==null) return;
        await RunAsync(async ()=>
        {
            Status.Text=$"{target.Name} 복원 중…";
            using var cancellation=new CancellationTokenSource(); opening=cancellation; CancelButton.Visibility=Visibility.Visible;
            WorkspaceOpenResult result;
            try { result=await Task.Run(()=>service.OpenAsync(target,document.Workspaces,cancellation.Token)); }
            finally { opening=null; CancelButton.Visibility=Visibility.Collapsed; }
            Results.ItemsSource=result.Items; ResultsPanel.IsExpanded=!result.Completed;
            if(result.Completed)
            {
                try
                {
                    document=await Task.Run(()=>store.Save(document with { LastWorkspaceId=target.Id },document.Revision));
                    RenderCards(); Status.Text=$"{target.Name} 복원 완료.";
                }
                catch(Exception ex) { Status.Text=$"창 복원은 완료했지만 최근 Workspace 기록을 저장하지 못했습니다. {ex.Message}"; }
            }
            else { Status.Text=$"{target.Name}: 일부 작업을 완료하지 못했습니다. 작업 결과를 확인하세요."; ShowMain(); }
        });
    }
    public void ShowMain() { Show(); if(WindowState==System.Windows.WindowState.Minimized) WindowState=System.Windows.WindowState.Normal; Activate(); }
    public void PrepareExit() { opening?.Cancel(); hotkeys?.Dispose(); hotkeys=null; tray?.Dispose(); tray=null; }
    private void RequestExit() { exiting=true; opening?.Cancel(); if(!busy) Close(); }
    private async void Preferences_Click(object sender,RoutedEventArgs e)=>await RunAsync(()=>
    { new SettingsWindow { Owner=this }.ShowDialog(); return Task.CompletedTask; });
    private void Cancel_Click(object sender,RoutedEventArgs e)
    { opening?.Cancel(); Status.Text="대기 중단 요청 중…"; }
    private void Settings_Click(object sender,RoutedEventArgs e)
    { if(sender is Button { ContextMenu: { } menu } button) { menu.PlacementTarget=button; menu.Placement=PlacementMode.Bottom; menu.IsOpen=true; } }
    private async void Reload_Click(object sender,RoutedEventArgs e)=>await RunAsync(LoadAsync);
    private async void Diagnostics_Click(object sender,RoutedEventArgs e)=>await RunAsync(()=>
    { new MainWindow { Owner=this }.ShowDialog(); return Task.CompletedTask; });
}
