using System.ComponentModel;
using findowgrid.Engine.Models;
namespace findowgrid.TestHost;
public sealed class SelectableWindow(WindowInfo window) : INotifyPropertyChanged
{
    public WindowInfo Window { get; } = window;
    public string AppName => Window.AppName;
    public string Title => Window.Title;
    public string State => Window.State.ToString();
    private bool selected;
    public bool Selected
    {
        get => selected;
        set { if (selected==value) return; selected=value; PropertyChanged?.Invoke(this,new(nameof(Selected))); }
    }
    public event PropertyChangedEventHandler? PropertyChanged;
}
