using findowgrid.Engine.Models;
namespace findowgrid.TestHost;
public sealed record WorkspaceCard(Workspace Workspace,bool IsRecent)
{
    public string Name=>Workspace.Name;
    public string Detail=>$"{Workspace.Windows.Count}개 창 · {Workspace.Windows.Select(e=>(e.Snapshot.Monitor.DeviceName,e.Snapshot.Monitor.Bounds)).Distinct().Count()}개 화면";
    public string RecentLabel=>string.Join(" · ",new[]{IsRecent ? "최근 사용" : null,Workspace.Hotkey?.ToString()}.Where(s=>s!=null));
}
