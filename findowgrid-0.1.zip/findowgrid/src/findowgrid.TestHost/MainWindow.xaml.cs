using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using findowgrid.Engine.Models;
using findowgrid.Engine.Services;
using findowgrid.Engine.Storage;
namespace findowgrid.TestHost;
public partial class MainWindow : Window
{
    private readonly WindowEnumerator enumerator = new();
    private readonly PlacementService placement = new();
    private readonly SnapshotStore store = new();
    private WindowSnapshot? snapshot;
    private bool busy;
    private WindowInfo? moveTarget;
    private bool corruptFile;
    private WindowInfo? Selected => WindowList.SelectedItem as WindowInfo;
    public MainWindow()
    {
        InitializeComponent();
        Loaded += async (_, _) =>
        {
            string? loadError = null;
            try { snapshot = store.Load(); }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or JsonException or ArgumentException)
            { corruptFile = true; loadError = "저장 파일을 읽지 못했습니다. 파일을 보존했습니다. " + ex.Message; }
            UpdateSavedLabel();
            await RefreshAsync();
            if (loadError != null) Status.Text = loadError;
        };
        Closing += (_, e) => { if (busy) { e.Cancel = true; Status.Text = "현재 작업이 끝난 후 닫아주세요."; } };
    }
    private async Task RunAsync(Func<Task> action)
    {
        if (busy) return;
        busy = true; Root.IsEnabled = false;
        try { await action(); }
        catch (Exception ex) { Status.Text = "작업 실패: " + ex.Message; }
        finally { busy = false; Root.IsEnabled = true; UpdateButtons(); }
    }
    private Task RefreshAsync() => RunAsync(async () =>
    {
        bool extra = Extra.IsChecked == true;
        var items = await Task.Run(() => enumerator.Enumerate(extra));
        WindowList.ItemsSource = items;
        Status.Text = $"{items.Count}개 창을 찾았습니다. 저장할 창을 선택하세요.";
    });
    private async void Refresh_Click(object sender, RoutedEventArgs e) => await RefreshAsync();
    private async void Extra_Changed(object sender, RoutedEventArgs e) { if (IsLoaded) await RefreshAsync(); }
    private void Selection_Changed(object sender, SelectionChangedEventArgs e)
    { Details.Text = Selected?.Details ?? ""; UpdateButtons(); }
    private void UpdateButtons()
    {
        if (SaveButton == null) return;
        SaveButton.IsEnabled = !busy && Selected != null;
        MoveButton.IsEnabled = !busy && Selected != null && snapshot != null && moveTarget != null && Selected.Handle == moveTarget.Handle;
        RestoreButton.IsEnabled = !busy && Selected != null && snapshot != null;
    }
    private void UpdateSavedLabel() => SavedLabel.Text = snapshot == null ? "저장된 위치 없음" : $"저장됨: {snapshot.Identity.ProcessName} · {snapshot.Identity.Title} · {snapshot.SavedAt.ToLocalTime():g}";
    private async void Save_Click(object sender, RoutedEventArgs e)
    {
        var selected = Selected; if (selected == null) return;
        if (corruptFile)
        {
            MessageBox.Show(this,$"읽을 수 없는 기존 파일을 자동으로 덮어쓰지 않습니다. 파일 이름을 바꾸거나 옮긴 뒤 findowgrid을 다시 실행하세요.\n\n{store.FilePath}","배치 파일 확인");
            return;
        }
        await RunAsync(async () =>
        {
            var captured = await Task.Run(() => placement.Capture(selected));
            await Task.Run(() => store.Save(captured));
            snapshot = captured; moveTarget = selected; UpdateSavedLabel(); Status.Text = "위치를 저장했습니다. 이제 테스트 이동 후 복원하세요.";
        });
    }
    private async void Move_Click(object sender, RoutedEventArgs e)
    {
        var selected = Selected; if (selected == null || snapshot == null) return;
        // Always save this exact target before a test move, so Restore can undo it.
        if (moveTarget == null || selected.Handle != moveTarget.Handle || selected.ProcessId != moveTarget.ProcessId || selected.ProcessStartTicks != moveTarget.ProcessStartTicks)
        { Status.Text = "이 창의 위치를 먼저 저장하세요."; return; }
        await RunAsync(async () => ShowResult(await placement.TestMoveAsync(selected)));
    }
    private async void Restore_Click(object sender, RoutedEventArgs e)
    {
        var selected = Selected; var saved = snapshot;
        if (selected == null || saved == null) return;
        if (MessageBox.Show(this,$"저장한 배치를 현재 선택한 창에 적용합니다.\n\n선택: {selected.Title}\n저장: {saved.Identity.Title}\n\nPhase 1에서는 대상 창을 직접 선택합니다.","배치 복원",MessageBoxButton.OKCancel) != MessageBoxResult.OK) return;
        await RunAsync(async () => ShowResult(await placement.RestoreAsync(selected,saved)));
    }
    private void ShowResult(WindowOperationResult result) => Status.Text = $"{result.Status}: {result.Message}" +
        (result.Status == OperationStatus.Partial ? $"\n목표: {result.Expected}\n실제: {result.Actual}" : "");
}
