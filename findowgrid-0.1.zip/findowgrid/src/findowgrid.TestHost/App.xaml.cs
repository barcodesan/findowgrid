using System.Windows;
namespace findowgrid.TestHost;
public partial class App : Application
{
    private Mutex? instance;
    private EventWaitHandle? activate;
    private RegisteredWaitHandle? waiter;
    public bool Ending { get; private set; }
    protected override void OnStartup(StartupEventArgs e)
    {
        // Per-user/session names avoid cross-user interference.
        string suffix=System.Security.Principal.WindowsIdentity.GetCurrent().User?.Value ?? Environment.UserName;
        instance=new Mutex(true,@"Local\findowgrid-"+suffix,out bool first);
        activate=new EventWaitHandle(false,EventResetMode.AutoReset,@"Local\findowgrid-show-"+suffix);
        if(!first) { activate.Set(); Shutdown(); return; }
        waiter=ThreadPool.RegisterWaitForSingleObject(activate,(_,_)=>Dispatcher.BeginInvoke(new Action(()=>
        { if(MainWindow is WorkspaceWindow window) window.ShowMain(); })),null,Timeout.Infinite,false);
        SessionEnding+=(_,_)=> { Ending=true; if(MainWindow is WorkspaceWindow window) window.PrepareExit(); };
        base.OnStartup(e);
    }
    protected override void OnExit(ExitEventArgs e)
    { waiter?.Unregister(null); activate?.Dispose(); instance?.Dispose(); base.OnExit(e); }
}
