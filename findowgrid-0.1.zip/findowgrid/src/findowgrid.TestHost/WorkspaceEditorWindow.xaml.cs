using System.IO;
using System.Windows;
using System.Windows.Controls;
using findowgrid.Engine.Models;
using findowgrid.Engine.Services;
using Entry=findowgrid.Engine.Models.WorkspaceWindow;
namespace findowgrid.TestHost;
public partial class WorkspaceEditorWindow : Window
{
    private WorkspaceDraft draft;
    private readonly WorkspaceService service;
    private readonly Func<WorkspaceDraft,Task> save;
    private readonly Func<Task>? delete;
    private bool busy;
    private HotkeySpec? hotkey;
    public WorkspaceEditorWindow(WorkspaceDraft original,WorkspaceService service,Func<WorkspaceDraft,Task> save,Func<Task>? delete=null)
    {
        InitializeComponent();
        draft=new(WorkspaceEdits.Clone(original.Workspace),original.Bindings.ToDictionary(p=>p.Key,p=>p.Value));
        this.service=service; this.save=save; this.delete=delete;
        hotkey=draft.Workspace.Hotkey; HotkeyBox.Text=hotkey?.ToString() ?? "클릭 후 키 조합 입력";
        NameBox.Text=draft.Workspace.Name; Heading.Text=delete==null ? "현재 Workspace 저장" : "Workspace 편집";
        DeleteButton.Visibility=delete==null ? Visibility.Collapsed : Visibility.Visible;
        Refresh(); Loaded+=(_,_)=>{ NameBox.Focus(); if(delete==null) NameBox.SelectAll(); };
        Closing+=(_,e)=>{ if(busy) { e.Cancel=true; Status.Text="현재 작업이 끝난 후 닫아주세요."; } };
    }
    private void ClearHotkey_Click(object sender,RoutedEventArgs e)
    { hotkey=null; HotkeyBox.Text="클릭 후 키 조합 입력"; }
    private void Hotkey_KeyDown(object sender,System.Windows.Input.KeyEventArgs e)
    {
        e.Handled=true;
        var key=e.Key==System.Windows.Input.Key.System ? e.SystemKey : e.Key;
        var modifiers=System.Windows.Input.Keyboard.Modifiers;
        uint flags=((modifiers&System.Windows.Input.ModifierKeys.Alt)!=0?1u:0u)
            |((modifiers&System.Windows.Input.ModifierKeys.Control)!=0?2u:0u)
            |((modifiers&System.Windows.Input.ModifierKeys.Shift)!=0?4u:0u)
            |((modifiers&System.Windows.Input.ModifierKeys.Windows)!=0?8u:0u);
        try { var candidate=new HotkeySpec(flags,(uint)System.Windows.Input.KeyInterop.VirtualKeyFromKey(key)); candidate.Validate(); hotkey=candidate; HotkeyBox.Text=candidate.ToString(); Status.Text="SAVE를 누르면 단축키 충돌을 확인하고 적용합니다."; }
        catch(InvalidDataException) { Status.Text="Ctrl·Alt·Shift·Win과 숫자·영문자·F1~F11을 조합하세요."; }
    }
    private void Refresh(Guid? selected=null)
    {
        Entries.ItemsSource=draft.Workspace.Windows;
        Entries.SelectedItem=draft.Workspace.Windows.FirstOrDefault(e=>e.Id==selected) ?? draft.Workspace.Windows.FirstOrDefault();
        Preview.Workspace=draft.Workspace;
        CountLabel.Text=$"등록된 창 {draft.Workspace.Windows.Count}개";
        UpdateButton.IsEnabled=draft.Workspace.Windows.Count>0;
        UpdateEntryButtons();
    }
    private void UpdateEntryButtons()
    { if(RemoveButton==null) return; RemoveButton.IsEnabled=Entries.SelectedItem!=null; LaunchButton.IsEnabled=Entries.SelectedItem!=null; }
    private void Entry_Changed(object sender,SelectionChangedEventArgs e)=>UpdateEntryButtons();
    private async Task RunAsync(Func<Task> action)
    {
        if(busy) return; busy=true; Root.IsEnabled=false;
        try { await action(); }
        catch(Exception ex) { Status.Text=ex.Message; }
        finally { busy=false; Root.IsEnabled=true; }
    }
    private async void Add_Click(object sender,RoutedEventArgs e)
    {
        var picker=new WindowPickerWindow { Owner=this };
        if(picker.ShowDialog()!=true) return;
        await RunAsync(async ()=>
        {
            var updated=await Task.Run(()=>service.AddWindows(draft,picker.SelectedWindows));
            draft=updated; Refresh(draft.Workspace.Windows.Last().Id); Status.Text="창을 추가했습니다. SAVE를 누르면 적용됩니다.";
        });
    }
    private void Remove_Click(object sender,RoutedEventArgs e)
    {
        if(Entries.SelectedItem is not Entry entry) return;
        draft=WorkspaceEdits.Remove(draft,entry.Id); Refresh(); Status.Text="목록에서 제거했습니다. 실제 프로그램은 닫지 않습니다.";
    }
    private void Launch_Click(object sender,RoutedEventArgs e)
    {
        var dialog=new LaunchSettingsWindow(draft.Workspace,Math.Max(0,Entries.SelectedIndex)) { Owner=this };
        if(dialog.ShowDialog()!=true || dialog.EditedWorkspace is not { } updated) return;
        draft=draft with { Workspace=updated }; Refresh(); Status.Text="실행 설정을 변경했습니다. SAVE를 누르면 적용됩니다.";
    }
    private async void Update_Click(object sender,RoutedEventArgs e)=>await RunAsync(async ()=>
    {
        Status.Text="현재 배치를 읽는 중입니다…";
        var result=await Task.Run(()=>service.CaptureCurrentLayout(draft));
        if(result.Draft is { } updated)
        { draft=updated; Refresh(); Status.Text="현재 배치로 업데이트했습니다. SAVE를 누르면 적용됩니다."; }
        else Status.Text="기존 배치를 유지했습니다.\n"+string.Join("\n",result.Items.Where(r=>r.Status!=OperationStatus.Success).Select(r=>$"{r.WindowName}: {r.Message}"));
    });
    private async void Save_Click(object sender,RoutedEventArgs e)
    {
        bool succeeded=false;
        await RunAsync(async ()=>
        {
            var updated=draft with { Workspace=draft.Workspace with { Name=NameBox.Text.Trim(), Hotkey=hotkey } };
            await save(updated); succeeded=true;
        });
        // Close only after the durable write succeeds; on conflict keep the draft on screen.
        if(succeeded) DialogResult=true;
    }
    private async void Delete_Click(object sender,RoutedEventArgs e)
    {
        if(delete==null || MessageBox.Show(this,$"‘{draft.Workspace.Name}’ Workspace를 삭제할까요?\n열린 프로그램은 닫지 않습니다.","Workspace 삭제",MessageBoxButton.YesNo,MessageBoxImage.Question)!=MessageBoxResult.Yes) return;
        bool succeeded=false;
        await RunAsync(async ()=>{ await delete(); succeeded=true; });
        if(succeeded) DialogResult=true;
    }
}
