using System.Globalization;
using System.Windows;
using System.Windows.Media;
using findowgrid.Engine.Models;
using findowgrid.Engine.Services;
namespace findowgrid.TestHost.Controls;
public sealed class WorkspacePreview : FrameworkElement
{
    public static readonly DependencyProperty WorkspaceProperty=DependencyProperty.Register(nameof(Workspace),typeof(Workspace),typeof(WorkspacePreview),new FrameworkPropertyMetadata(null,FrameworkPropertyMetadataOptions.AffectsRender));
    public Workspace? Workspace { get=>(Workspace?)GetValue(WorkspaceProperty); set=>SetValue(WorkspaceProperty,value); }
    private static readonly string[] Palette=["#426B9F","#287C75","#6D6DB1","#967349","#5C8290"];
    private static Brush Color(string value)=>new SolidColorBrush((System.Windows.Media.Color)ColorConverter.ConvertFromString(value));
    protected override void OnRender(DrawingContext dc)
    {
        base.OnRender(dc);
        var scene=WorkspacePreviewLayout.Build(Workspace,ActualWidth,ActualHeight);
        dc.PushClip(new RectangleGeometry(new Rect(0,0,ActualWidth,ActualHeight)));
        foreach(var monitor in scene.Monitors)
        {
            var r=monitor.Bounds;
            dc.DrawRoundedRectangle(Color("#DCE4EF"),new Pen(Color("#B6C4D6"),1),new Rect(r.X,r.Y,r.Width,r.Height),3,3);
        }
        foreach(var window in scene.Windows)
        {
            var r=window.Bounds;
            dc.PushOpacity(window.Minimized ? .40 : .92);
            var border=new Pen(Brushes.White,.8);
            if(window.Minimized) border.DashStyle=DashStyles.Dash;
            dc.DrawRoundedRectangle(Color(Palette[window.ColorIndex]),border,new Rect(r.X,r.Y,r.Width,r.Height),2,2);
            if(r.Width>40 && r.Height>20)
            {
                var label=new FormattedText(window.Label,CultureInfo.CurrentUICulture,FlowDirection.LeftToRight,
                    new Typeface("Segoe UI"),10,Brushes.White,VisualTreeHelper.GetDpi(this).PixelsPerDip)
                { MaxTextWidth=Math.Max(1,r.Width-10),MaxTextHeight=Math.Max(1,r.Height-8),Trimming=TextTrimming.CharacterEllipsis };
                dc.DrawText(label,new Point(r.X+5,r.Y+4));
            }
            dc.Pop();
        }
        dc.Pop();
    }
}
