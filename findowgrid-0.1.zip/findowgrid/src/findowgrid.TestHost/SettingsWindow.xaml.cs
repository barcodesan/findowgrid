using System.Windows;
using findowgrid.TestHost.Integration;
namespace findowgrid.TestHost;
public partial class SettingsWindow : Window
{
    private readonly SettingsStore store=new();
    public SettingsWindow()
    { InitializeComponent(); AutoStart.IsChecked=StartupRegistration.Read()!=null; RestoreLast.IsChecked=store.Load().RestoreLast; }
    private void Save_Click(object sender,RoutedEventArgs e)
    {
        try
        {
            if(RestoreLast.IsChecked==true && AutoStart.IsChecked!=true) throw new InvalidOperationException("로그인 시 복원하려면 Windows 자동 시작도 켜주세요.");
            string? previous=StartupRegistration.Read();
            StartupRegistration.Write(AutoStart.IsChecked==true ? StartupRegistration.Command() : null);
            try { store.Save(new(RestoreLast.IsChecked==true)); }
            catch { StartupRegistration.Write(previous); throw; }
            DialogResult=true;
        }
        catch(Exception ex) { Status.Text="설정을 저장하지 못했습니다: "+ex.Message; }
    }
}
