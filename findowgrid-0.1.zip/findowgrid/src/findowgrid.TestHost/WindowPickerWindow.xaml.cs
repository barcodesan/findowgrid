using System.Windows;
using findowgrid.Engine.Models;
using findowgrid.Engine.Services;
namespace findowgrid.TestHost;
public partial class WindowPickerWindow : Window
{
    private List<SelectableWindow> choices=[];
    private bool busy;
    public IReadOnlyList<WindowInfo> SelectedWindows { get; private set; }=[];
    public WindowPickerWindow()
    {
        InitializeComponent(); Loaded+=async (_,_)=>await RefreshAsync();
        Closing+=(_,e)=>{ if(busy) e.Cancel=true; };
    }
    private async Task RefreshAsync()
    {
        if(busy) return; busy=true; Root.IsEnabled=false; string? error=null;
        try
        {
            var selected=choices.Where(c=>c.Selected).Select(c=>c.Window).ToArray(); bool extra=Extra.IsChecked==true;
            var live=await Task.Run(()=>new WindowEnumerator().Enumerate(extra));
            choices=live.Select(w=>new SelectableWindow(w) { Selected=selected.Any(old=>ExactWindowResolver.SameLiveWindow(old,w)) }).ToList();
            foreach(var item in choices) item.PropertyChanged+=(_,_)=>UpdateCount();
            Windows.ItemsSource=choices;
        }
        catch(Exception ex) { error="창 목록을 읽지 못했습니다. "+ex.Message; }
        finally { busy=false; Root.IsEnabled=true; UpdateCount(); if(error!=null) Status.Text=error; }
    }
    private void UpdateCount()
    { int count=choices.Count(c=>c.Selected); Status.Text=$"{count}개 선택 / {choices.Count}개 창"; ChooseButton.IsEnabled=count is >0 and <=64; }
    private async void Refresh_Click(object sender,RoutedEventArgs e)=>await RefreshAsync();
    private async void Extra_Changed(object sender,RoutedEventArgs e) { if(IsLoaded) await RefreshAsync(); }
    private void SelectAll_Click(object sender,RoutedEventArgs e) { foreach(var c in choices) c.Selected=true; }
    private void Clear_Click(object sender,RoutedEventArgs e) { foreach(var c in choices) c.Selected=false; }
    private void Choose_Click(object sender,RoutedEventArgs e)
    { SelectedWindows=choices.Where(c=>c.Selected).Select(c=>c.Window).ToArray(); if(SelectedWindows.Count is >0 and <=64) DialogResult=true; }
}
