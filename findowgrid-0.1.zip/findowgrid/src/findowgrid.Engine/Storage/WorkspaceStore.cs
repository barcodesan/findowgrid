using System.Text.Json;
using System.Text.Json.Serialization;
using findowgrid.Engine.Models;
using findowgrid.Engine.Services;
namespace findowgrid.Engine.Storage;
public sealed class WorkspaceStore
{
    public string FilePath { get; }
    private static readonly JsonSerializerOptions Options = new()
    {
        WriteIndented = true, Converters = { new JsonStringEnumConverter() },
        PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower
    };
    private readonly string? legacyPath;
    public bool LoadedLegacyData { get; private set; }
    public WorkspaceStore(string? path = null, string? legacyFilePath = null)
    {
        FilePath=Path.GetFullPath(path ?? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"findowgrid","workspaces.json"));
        legacyPath=legacyFilePath ?? (path==null ? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"StockZone","workspaces.json") : null);
    }
    public WorkspaceDocument Load()
    {
        string source=FilePath;
        if(!File.Exists(source) && legacyPath!=null && File.Exists(legacyPath)) source=legacyPath;
        if(!File.Exists(source)) return WorkspaceDocument.Empty;
        if(new FileInfo(source).Length>16*1024*1024) throw new InvalidDataException("Workspace 파일이 너무 큽니다.");
        using var stream=new FileStream(source,FileMode.Open,FileAccess.Read,FileShare.Read|FileShare.Delete);
        var doc=JsonSerializer.Deserialize<WorkspaceDocument>(stream,Options) ?? throw new InvalidDataException("Workspace 파일이 비어 있습니다.");
        Validate(doc);
        LoadedLegacyData=source!=FilePath;
        return doc with { SchemaVersion=2,Workspaces=doc.Workspaces.Select(w=>w with
        { Windows=w.Windows.Select(e=>e with { Launch=e.Launch ?? WorkspaceService.DefaultLaunch(e.Snapshot.Identity) }).ToList() }).ToList() };
    }
    public WorkspaceDocument Save(WorkspaceDocument document, long expectedRevision)
    {
        Validate(document);
        Directory.CreateDirectory(Path.GetDirectoryName(FilePath)!);
        // Shared by all findowgrid instances. An abandoned lock file is harmless; the OS releases its handle.
        using var fileLock = new FileStream(FilePath+".lock",FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None);
        var existing = Load(); // A corrupt file is never silently replaced.
        if (existing.Revision != expectedRevision)
            throw new InvalidOperationException("다른 실행 창에서 Workspace가 변경되었습니다. JSON 다시 불러오기를 누른 뒤 다시 저장하세요.");
        var next = document with { SchemaVersion=2, Revision=checked(existing.Revision+1) };
        Validate(next);
        byte[] bytes = JsonSerializer.SerializeToUtf8Bytes(next,Options);
        if (bytes.Length > 16*1024*1024) throw new InvalidDataException("Workspace 파일 크기 제한을 초과했습니다.");
        var temp = FilePath+"."+Guid.NewGuid().ToString("N")+".tmp";
        try
        {
            using (var stream = new FileStream(temp,FileMode.CreateNew,FileAccess.Write,FileShare.None))
            { stream.Write(bytes); stream.Flush(true); }
            if (File.Exists(FilePath)) File.Replace(temp,FilePath,FilePath+".bak",true);
            else File.Move(temp,FilePath);
        }
        finally { if (File.Exists(temp)) File.Delete(temp); }
        return next;
    }
    public static void Validate(WorkspaceDocument doc)
    {
        if (doc.SchemaVersion is not (1 or 2) || doc.Revision < 0 || doc.Workspaces == null || doc.Workspaces.Count > 100)
            throw new InvalidDataException("지원하지 않거나 손상된 Workspace 파일입니다.");
        var ids = new HashSet<Guid>(); var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var w in doc.Workspaces)
        {
            if (w == null || w.Id == Guid.Empty || !ids.Add(w.Id) || string.IsNullOrWhiteSpace(w.Name) ||
                w.Name != w.Name.Trim() || w.Name.Length > 80 || !names.Add(w.Name) || w.Windows == null || w.Windows.Count is < 1 or > 64)
                throw new InvalidDataException("Workspace 이름·ID·창 목록이 올바르지 않습니다.");
            w.Hotkey?.Validate();
            if(w.Hotkey != null && doc.Workspaces.Any(other=>other.Id!=w.Id && other.Hotkey==w.Hotkey))
                throw new InvalidDataException("다른 Workspace에서 사용하는 단축키입니다.");
            var entries = new HashSet<Guid>();
            foreach (var entry in w.Windows)
            {
                if (entry == null || entry.Id == Guid.Empty || !entries.Add(entry.Id) || entry.Snapshot == null)
                    throw new InvalidDataException("Workspace 창 항목이 올바르지 않습니다.");
                SnapshotStore.Validate(entry.Snapshot);
                LaunchValidation.Validate(entry.Launch);
                if(entry.Match?.TitleContains is { } pattern && (pattern.Trim().Length<3 || pattern.Length>256))
                    throw new InvalidDataException("제목 조건은 3~256자로 입력하세요.");
            }
        }
        if (doc.LastWorkspaceId.HasValue && !ids.Contains(doc.LastWorkspaceId.Value))
            throw new InvalidDataException("마지막 Workspace ID가 목록에 없습니다.");
    }
}
