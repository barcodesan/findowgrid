using System.Text.Json;
using System.Text.Json.Serialization;
using findowgrid.Engine.Models;
namespace findowgrid.Engine.Storage;
public sealed class SnapshotStore
{
    public string FilePath { get; }
    private static readonly JsonSerializerOptions Options = new() { WriteIndented = true, Converters = { new JsonStringEnumConverter() } };
    public SnapshotStore(string? path = null) => FilePath = path ?? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "findowgrid", "Phase1", "snapshot.json");
    public void Save(WindowSnapshot snapshot)
    {
        Validate(snapshot);
        Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(FilePath))!);
        string temporary = FilePath+"."+Guid.NewGuid().ToString("N")+".tmp";
        try
        {
            using (var stream = new FileStream(temporary,FileMode.CreateNew,FileAccess.Write,FileShare.None))
            { JsonSerializer.Serialize(stream,snapshot,Options); stream.Flush(true); }
            if (File.Exists(FilePath)) File.Replace(temporary,FilePath,FilePath+".bak",true);
            else File.Move(temporary,FilePath);
        }
        finally { if (File.Exists(temporary)) File.Delete(temporary); }
    }
    public WindowSnapshot? Load()
    {
        if (!File.Exists(FilePath)) return null;
        if (new FileInfo(FilePath).Length > 1024*1024) throw new InvalidDataException("배치 파일이 너무 큽니다.");
        using var stream = File.OpenRead(FilePath);
        var result = JsonSerializer.Deserialize<WindowSnapshot>(stream,Options) ?? throw new InvalidDataException("배치 파일이 비어 있습니다.");
        Validate(result);
        return result;
    }
    public static void Validate(WindowSnapshot s)
    {
        if (s.SchemaVersion != 1 || s.Identity == null || string.IsNullOrWhiteSpace(s.Identity.ClassName) ||
            string.IsNullOrWhiteSpace(s.Identity.ProcessName) || s.Identity.Title == null || s.Identity.Title.Length>4096 || s.NormalBoundsScreenPx?.IsValid != true ||
            s.Monitor == null || string.IsNullOrWhiteSpace(s.Monitor.DeviceName) || s.Monitor.Bounds?.IsValid != true ||
            s.Monitor.WorkArea?.IsValid != true || (s.VisibleBoundsPx != null && !s.VisibleBoundsPx.IsValid) || !Enum.IsDefined(s.State))
            throw new InvalidDataException("지원하지 않거나 손상된 배치 파일입니다. 원본 파일은 변경하지 않았습니다.");
    }
}
