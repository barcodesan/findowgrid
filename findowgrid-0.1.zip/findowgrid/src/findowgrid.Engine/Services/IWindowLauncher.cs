using findowgrid.Engine.Models;
namespace findowgrid.Engine.Services;
public interface IWindowLauncher
{
    Task<LaunchTicket> LaunchAsync(LaunchSpec spec,CancellationToken cancellationToken);
}
