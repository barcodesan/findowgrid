using findowgrid.Engine.Models;
namespace findowgrid.Engine.Services;
public static class BrowserLaunchPolicy
{
    public static bool IsChrome(string? path) => !string.IsNullOrWhiteSpace(path)
        && path.Replace('\\','/').Split('/').Last().Equals("chrome.exe",StringComparison.OrdinalIgnoreCase);
    private static bool IsHttpUrl(string? value) => Uri.TryCreate(value,UriKind.Absolute,out var uri)
        && uri.Scheme is "http" or "https" && !string.IsNullOrWhiteSpace(uri.Host);
    public static bool RequiresFreshWindow(LaunchSpec? spec) => spec!=null
        && IsChrome(spec.Kind==LaunchKind.Url ? spec.BrowserPath : spec.ExecutablePath)
        && (spec.BrowserWindow==BrowserWindowMode.NewWindow || (spec.Arguments?.Contains("--new-window")==true));
    public static LaunchSpec Prepare(WorkspaceWindow entry)
    {
        var spec=entry.Launch ?? throw new InvalidOperationException("실행 정보가 없습니다.");
        LaunchValidation.Validate(spec);
        if(spec.Kind==LaunchKind.None || spec.Behavior==LaunchBehavior.ReuseOnly) return spec;
        string? path=spec.Kind==LaunchKind.Application ? spec.ExecutablePath : spec.BrowserPath;
        // For saved Chrome windows we know the executable, without inspecting sessions or registry defaults.
        if(spec.Kind==LaunchKind.Url && string.IsNullOrWhiteSpace(path)
            && spec.BrowserWindow!=BrowserWindowMode.BrowserDefault && IsChrome(entry.Snapshot.Identity.ExecutablePath))
            path=entry.Snapshot.Identity.ExecutablePath;
        if(spec.BrowserWindow==BrowserWindowMode.BrowserDefault) return spec;
        if(!IsChrome(path))
        {
            if(spec.BrowserWindow==BrowserWindowMode.NewWindow)
                throw new InvalidOperationException("독립 창 실행에는 Chrome 실행 경로를 지정하세요. 다른 브라우저는 기본 동작을 선택하세요.");
            return spec;
        }
        var args=(spec.Arguments ?? []).ToList();
        if(args.Any(a=>a.Equals("--new-tab",StringComparison.OrdinalIgnoreCase)
            || a.Equals("--app",StringComparison.OrdinalIgnoreCase) || a.StartsWith("--app=",StringComparison.OrdinalIgnoreCase)
            || a.StartsWith("--app-id",StringComparison.OrdinalIgnoreCase)))
            throw new InvalidOperationException("독립 창과 충돌하는 실행 인수가 있습니다. --new-tab/--app/--app-id를 제거하거나 브라우저 기본 동작을 선택하세요.");
        if(!string.IsNullOrWhiteSpace(spec.Url))
        {
            if(!IsHttpUrl(spec.Url)) throw new InvalidDataException("Chrome 복원 주소는 http:// 또는 https:// 형식이어야 합니다.");
            // Application entries also accept the dedicated URL field; never append it twice.
            if(!args.Contains(spec.Url,StringComparer.Ordinal)) args.Add(spec.Url);
        }
        if(!args.Any(IsHttpUrl))
            throw new InvalidOperationException("이 Chrome 창의 웹 주소가 저장되어 있지 않습니다. EDIT → 실행 설정에서 해당 창의 URL을 입력한 뒤 SAVE하세요. 창 제목만으로 주소를 복원할 수 없습니다.");
        args.RemoveAll(a=>a.Equals("--new-window",StringComparison.OrdinalIgnoreCase));
        args.Insert(0,"--new-window");
        // Canonical program launch avoids the default-browser shell path (which may reuse a tab).
        var prepared=spec with { Kind=LaunchKind.Application,ExecutablePath=path,Arguments=args,BrowserWindow=BrowserWindowMode.NewWindow };
        LaunchValidation.Validate(prepared);
        return prepared;
    }
}
