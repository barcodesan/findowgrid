using System.Diagnostics;
using findowgrid.Engine.Models;
namespace findowgrid.Engine.Services;
public sealed class WindowLauncher : IWindowLauncher
{
    public Task<LaunchTicket> LaunchAsync(LaunchSpec spec,CancellationToken cancellationToken) => Task.Run(() =>
    {
        cancellationToken.ThrowIfCancellationRequested();
        LaunchValidation.Validate(spec);
        var info=LaunchCommand.Create(spec);
        if(!info.UseShellExecute && !File.Exists(info.FileName))
            throw new FileNotFoundException("실행 파일을 찾을 수 없습니다. 실행 설정에서 경로를 확인하세요.");
        // Never assemble shell command strings, elevate, inject, or read a browser session.
        using var process=Process.Start(info);
        uint? pid=null;
        try { if(process!=null) pid=(uint)process.Id; } catch(InvalidOperationException) { }
        return new LaunchTicket(pid,"실행 요청을 보냈습니다. 창 생성을 기다립니다.");
    },cancellationToken);
}
