using findowgrid.Engine.Models;
using findowgrid.Engine.Storage;
namespace findowgrid.Engine.Services;
public static class WorkspaceEdits
{
    public static Workspace Clone(Workspace workspace) => workspace with
    {
        Windows=workspace.Windows.Select(e=>e with { Launch=e.Launch is { } l ? l with { Arguments=l.Arguments?.ToList() } : null }).ToList()
    };
    public static WorkspaceDocument Upsert(WorkspaceDocument document,Workspace workspace)
    {
        var normalized=Clone(workspace with { Name=workspace.Name.Trim(),UpdatedAt=DateTimeOffset.UtcNow });
        var list=document.Workspaces.ToList();
        int index=list.FindIndex(w=>w.Id==normalized.Id);
        if(index<0) list.Add(normalized); else list[index]=normalized;
        var result=document with { Workspaces=list };
        WorkspaceStore.Validate(result);
        return result;
    }
    public static WorkspaceDocument Delete(WorkspaceDocument document,Guid id)
    {
        if(!document.Workspaces.Any(w=>w.Id==id)) throw new InvalidOperationException("Workspace가 이미 삭제되었습니다. 목록을 다시 불러오세요.");
        var result=document with { Workspaces=document.Workspaces.Where(w=>w.Id!=id).ToList(),LastWorkspaceId=document.LastWorkspaceId==id ? null : document.LastWorkspaceId };
        WorkspaceStore.Validate(result); return result;
    }
    public static WorkspaceDraft Remove(WorkspaceDraft draft,Guid entryId) => new(
        draft.Workspace with { Windows=draft.Workspace.Windows.Where(e=>e.Id!=entryId).ToList() },
        draft.Bindings.Where(p=>p.Key!=entryId).ToDictionary(p=>p.Key,p=>p.Value));
}
