using System.Diagnostics;
using findowgrid.Engine.Models;
namespace findowgrid.Engine.Services;
public sealed class WindowLaunchCoordinator(IWindowDesktop desktop,IWindowLauncher launcher,TimeSpan? pollInterval=null)
{
    private readonly Dictionary<(Guid,Guid),DateTimeOffset> attempts=[];
    public async Task<WindowMatch> LaunchAndWaitAsync(Guid workspaceId,WorkspaceWindow entry,ISet<nint> reserved,CancellationToken token)
    {
        var spec=entry.Launch;
        if(spec==null || spec.Kind==LaunchKind.None || spec.Behavior==LaunchBehavior.ReuseOnly)
            return new(null,MatchStatus.NotFound,"열린 창이 없고 자동 실행이 꺼져 있습니다.");
        var key=(workspaceId,entry.Id);
        if(attempts.TryGetValue(key,out var previous) && DateTimeOffset.UtcNow-previous<TimeSpan.FromSeconds(30))
            return new(null,MatchStatus.NotFound,"최근 실행 요청이 있습니다. 중복 실행을 막기 위해 30초 후 다시 시도하세요.");
        var before=desktop.Enumerate();
        var appeared=WindowMatcher.Resolve(entry,null,before,reserved);
        if(appeared.Window!=null) return appeared;
        // Resolve browser policy only after existing-window reuse; no URL is needed to move a live window.
        spec=BrowserLaunchPolicy.Prepare(entry);
        entry=entry with { Launch=spec };
        attempts[key]=DateTimeOffset.UtcNow;
        var ticket=await launcher.LaunchAsync(spec,token).ConfigureAwait(false);
        var context=new LaunchContext(before,ticket);
        var timer=Stopwatch.StartNew();
        WindowInfo? last=null; int stable=0;
        WindowMatch match=new(null,MatchStatus.NotFound,"창 생성을 기다리는 중입니다.");
        while(timer.Elapsed<TimeSpan.FromSeconds(spec.WaitSeconds))
        {
            await Task.Delay(pollInterval ?? TimeSpan.FromMilliseconds(200),token).ConfigureAwait(false);
            var live=desktop.Enumerate();
            match=WindowMatcher.Resolve(entry,null,live,reserved,context);
            if(match.Window is { } w)
            {
                stable=last!=null && ExactWindowResolver.SameLiveWindow(last,w) && last.Title==w.Title ? stable+1 : 1;
                last=w;
                if(stable>=3) return match;
            }
            else { stable=0; last=null; }
        }
        return new(null,match.Status==MatchStatus.Ambiguous ? MatchStatus.Ambiguous : MatchStatus.NotFound,
            $"{spec.WaitSeconds}초 안에 창을 확인하지 못했습니다. 재실행하지 않았습니다. {match.Reason}");
    }
}
