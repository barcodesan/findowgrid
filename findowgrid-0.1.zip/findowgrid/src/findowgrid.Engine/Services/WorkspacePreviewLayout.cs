using findowgrid.Engine.Models;
namespace findowgrid.Engine.Services;
public sealed record PreviewRect(double X,double Y,double Width,double Height);
public sealed record PreviewMonitor(PreviewRect Bounds,int Number);
public sealed record PreviewWindow(PreviewRect Bounds,string Label,bool Minimized,int ColorIndex);
public sealed record PreviewScene(IReadOnlyList<PreviewMonitor> Monitors,IReadOnlyList<PreviewWindow> Windows);
public static class WorkspacePreviewLayout
{
    public static PreviewScene Build(Workspace? workspace,double width,double height)
    {
        if(workspace==null || workspace.Windows.Count==0 || !double.IsFinite(width) || !double.IsFinite(height) || width<=16 || height<=16)
            return new([],[]);
        var monitors=workspace.Windows.Select(e=>e.Snapshot.Monitor).DistinctBy(m=>(m.DeviceName,m.Bounds)).ToArray();
        double left=monitors.Min(m=>m.Bounds.X), top=monitors.Min(m=>m.Bounds.Y);
        double right=monitors.Max(m=>(double)m.Bounds.X+m.Bounds.Width), bottom=monitors.Max(m=>(double)m.Bounds.Y+m.Bounds.Height);
        double scale=Math.Min((width-16)/(right-left),(height-16)/(bottom-top));
        double dx=(width-(right-left)*scale)/2, dy=(height-(bottom-top)*scale)/2;
        PreviewRect Project(PixelRect r)=>new(dx+(r.X-left)*scale,dy+(r.Y-top)*scale,r.Width*scale,r.Height*scale);
        var frames=monitors.Select((m,i)=>new PreviewMonitor(Project(m.Bounds),i+1)).ToArray();
        var windows=new List<PreviewWindow>();
        for(int i=0;i<workspace.Windows.Count;i++)
        {
            var s=workspace.Windows[i].Snapshot;
            var r=s.State==WindowState.Maximized || s.State==WindowState.Minimized && s.RestoreToMaximized
                ? s.Monitor.WorkArea : s.VisibleBoundsPx ?? s.NormalBoundsScreenPx;
            // Previews stay legible even if legacy coordinates lie outside the saved monitor.
            int x=Math.Max(r.X,s.Monitor.Bounds.X), y=Math.Max(r.Y,s.Monitor.Bounds.Y);
            int x2=Math.Min(r.X+r.Width,s.Monitor.Bounds.X+s.Monitor.Bounds.Width), y2=Math.Min(r.Y+r.Height,s.Monitor.Bounds.Y+s.Monitor.Bounds.Height);
            if(x2>x && y2>y) windows.Add(new(Project(new(x,y,x2-x,y2-y)),s.Identity.ProcessName,s.State==WindowState.Minimized,i%5));
        }
        return new(frames,windows);
    }
}
