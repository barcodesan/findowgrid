using findowgrid.Engine.Models;
namespace findowgrid.Engine.Services;
public static class LaunchValidation
{
    public static bool AbsoluteWindowsPath(string path) =>
        path.Length>=3 && char.IsAsciiLetter(path[0]) && path[1]==':' && path[2] is '\\' or '/'
        || path.StartsWith("\\\\",StringComparison.Ordinal) && path.Length>4;
    public static void Validate(LaunchSpec? spec)
    {
        if(spec == null) return;
        if(!Enum.IsDefined(spec.Kind) || !Enum.IsDefined(spec.Behavior) || !Enum.IsDefined(spec.BrowserWindow) || spec.WaitSeconds is < 1 or > 120)
            throw new InvalidDataException("실행 방식 또는 대기 시간이 올바르지 않습니다.");
        if(spec.Arguments is { } args && (args.Count>100 || args.Any(a=>a==null || a.Length>8192 || a.Contains('\0'))))
            throw new InvalidDataException("실행 인수 형식이 올바르지 않습니다.");
        if(spec.Kind==LaunchKind.Application) ValidateExe(spec.ExecutablePath);
        if(spec.Kind==LaunchKind.Url)
        {
            if(!Uri.TryCreate(spec.Url,UriKind.Absolute,out var uri) || uri.Scheme is not ("https" or "http") || string.IsNullOrWhiteSpace(uri.Host))
                throw new InvalidDataException("웹 주소는 http:// 또는 https:// 형식이어야 합니다.");
            if(!string.IsNullOrWhiteSpace(spec.BrowserPath)) ValidateExe(spec.BrowserPath);
        }
        if(!string.IsNullOrWhiteSpace(spec.WorkingDirectory) && !AbsoluteWindowsPath(spec.WorkingDirectory))
            throw new InvalidDataException("작업 폴더는 전체 경로로 입력하세요.");
    }
    private static void ValidateExe(string? path)
    {
        if(string.IsNullOrWhiteSpace(path) || !AbsoluteWindowsPath(path) || !path.EndsWith(".exe",StringComparison.OrdinalIgnoreCase) || path.Contains('\0'))
            throw new InvalidDataException("프로그램은 .exe 파일의 전체 경로를 지정하세요.");
    }
}
