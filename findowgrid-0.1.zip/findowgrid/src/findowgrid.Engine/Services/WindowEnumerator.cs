using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using findowgrid.Engine.Interop;
using findowgrid.Engine.Models;
using N = findowgrid.Engine.Interop.NativeMethods;
namespace findowgrid.Engine.Services;
public sealed class WindowEnumerator
{
    public IReadOnlyList<WindowInfo> Enumerate(bool includeExtra = false)
    {
        using var scope = new DpiScope();
        var windows = new List<WindowInfo>();
        N.EnumWindows((h, _) =>
        {
            try
            {
                N.GetWindowThreadProcessId(h, out uint pid);
                if (pid == Environment.ProcessId || !N.IsWindowVisible(h)) return true;
                if (N.DwmGetWindowAttribute(h, 14, out int cloaked, sizeof(int)) == 0 && cloaked != 0) return true;
                var w = Read(h);
                if (w.Identity.ClassName is "Shell_TrayWnd" or "Shell_SecondaryTrayWnd" or "Progman" or "WorkerW") return true;
                long style = (long)N.GetWindowLongPtr(h, -20);
                if (!includeExtra && ((style & 0x80) != 0 || string.IsNullOrWhiteSpace(w.Title))) return true;
                windows.Add(w);
            }
            catch (Exception ex) when (ex is Win32Exception or InvalidOperationException or ArgumentException)
            { /* A window may disappear during enumeration. Never let exceptions cross the native callback. */ }
            return true;
        }, 0);
        return windows.OrderBy(w => w.AppName).ThenBy(w => w.Title).ToArray();
    }
    public WindowInfo Read(nint hwnd)
    {
        using var scope = new DpiScope();
        if (!N.IsWindow(hwnd)) throw new InvalidOperationException("창이 이미 닫혔습니다.");
        N.GetWindowThreadProcessId(hwnd, out uint pid);
        var title = new StringBuilder(4096); N.GetWindowTextW(hwnd, title, title.Capacity);
        var cls = new StringBuilder(256); N.GetClassNameW(hwnd, cls, cls.Capacity);
        string name = $"Process {pid}"; string? path = null, diagnostic = null; long? started = null;
        try
        {
            using var p = Process.GetProcessById((int)pid);
            name = p.ProcessName;
            try { started = p.StartTime.ToUniversalTime().Ticks; } catch (Win32Exception) { }
            using var handle = N.OpenProcess(0x1000, false, pid);
            if (!handle.IsInvalid)
            {
                var buffer = new StringBuilder(32768); uint size = (uint)buffer.Capacity;
                if (N.QueryFullProcessImageNameW(handle, 0, buffer, ref size)) path = buffer.ToString();
            }
            if (path == null) diagnostic = "실행 경로를 조회할 권한이 없거나 프로세스가 종료되었습니다.";
        }
        catch (Exception ex) when (ex is Win32Exception or InvalidOperationException or ArgumentException)
        { diagnostic = "프로세스 정보를 모두 조회하지 못했습니다."; }
        var placement = N.WINDOWPLACEMENT.Create();
        if (!N.GetWindowPlacement(hwnd, ref placement) || !N.GetWindowRect(hwnd, out var outer))
            throw new Win32Exception(Marshal.GetLastWin32Error());
        var monitor = MonitorService.ForWindow(hwnd);
        var normal = MonitorService.FromNative(placement.NormalPosition);
        // WINDOWPLACEMENT uses workspace coordinates except for WS_EX_TOOLWINDOW.
        if (((long)N.GetWindowLongPtr(hwnd, -20) & 0x80) == 0)
            normal = normal with { X = normal.X + monitor.WorkArea.X-monitor.Bounds.X,
                Y = normal.Y + monitor.WorkArea.Y-monitor.Bounds.Y };
        var state = N.IsIconic(hwnd) ? WindowState.Minimized : N.IsZoomed(hwnd) ? WindowState.Maximized : WindowState.Normal;
        PixelRect? visible = null;
        if (state == WindowState.Normal && N.DwmGetFrameBounds(hwnd,9,out var frame,Marshal.SizeOf<N.RECT>()) == 0)
        {
            var bounds = MonitorService.FromNative(frame);
            if (bounds.IsValid) visible = bounds;
        }
        // A snapped normal window may retain a different rcNormalPosition. Capture what is on screen.
        if (state == WindowState.Normal) normal = MonitorService.FromNative(outer);
        return new(hwnd, pid, started, new(name, path, cls.ToString(), title.ToString()),
            MonitorService.FromNative(outer), normal,
            state,
            (placement.Flags & 2) != 0, monitor, N.GetDpiForWindow(hwnd), diagnostic, visible);
    }
    internal WindowInfo Validate(WindowInfo selected)
    {
        var now = Read(selected.Handle);
        if (now.ProcessId != selected.ProcessId || now.Identity.ClassName != selected.Identity.ClassName ||
            (selected.ProcessStartTicks.HasValue && now.ProcessStartTicks != selected.ProcessStartTicks) ||
            (selected.Identity.ExecutablePath != null && !string.Equals(selected.Identity.ExecutablePath, now.Identity.ExecutablePath, StringComparison.OrdinalIgnoreCase)))
            throw new InvalidOperationException("선택한 창이 변경되었습니다. 목록을 새로고침하고 다시 선택하세요.");
        return now;
    }
}
