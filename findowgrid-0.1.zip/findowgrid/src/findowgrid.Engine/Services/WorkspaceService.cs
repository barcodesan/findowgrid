using findowgrid.Engine.Models;
using findowgrid.Engine.Storage;
namespace findowgrid.Engine.Services;
public sealed class WorkspaceService(IWindowDesktop desktop, IWindowLauncher? launcher = null)
{
    private readonly WindowLaunchCoordinator? launchCoordinator = launcher == null ? null : new(desktop,launcher);
    private readonly Dictionary<(Guid Workspace,Guid Entry),WindowInfo> bindings = [];
    private readonly SemaphoreSlim gate = new(1,1);
    public CapturedWorkspace Capture(string name, IReadOnlyList<WindowInfo> selected)
    {
        if (selected.Count is < 1 or > 64 || selected.Select(w => w.Handle).Distinct().Count() != selected.Count)
            throw new ArgumentException("서로 다른 창을 1~64개 선택하세요.");
        var entries = selected.Select(w => new WorkspaceWindow(Guid.NewGuid(),desktop.Capture(w),DefaultLaunch(w.Identity))).ToList();
        var workspace = new Workspace(Guid.NewGuid(),name.Trim(),DateTimeOffset.UtcNow,entries);
        WorkspaceStore.Validate(new(1,0,null,[workspace]));
        return new(workspace,selected.ToArray());
    }
    public static LaunchSpec DefaultLaunch(WindowIdentity identity) =>
        identity.ExecutablePath is { } path && LaunchValidation.AbsoluteWindowsPath(path) && path.EndsWith(".exe",StringComparison.OrdinalIgnoreCase)
            ? new(LaunchKind.Application,path,[]) : new(LaunchKind.None,Behavior:LaunchBehavior.ReuseOnly);
    // Called only after the capture has been persisted successfully.
    public void Remember(CapturedWorkspace captured)
    {
        for (int i=0;i<captured.Workspace.Windows.Count;i++)
            bindings[(captured.Workspace.Id,captured.Workspace.Windows[i].Id)] = captured.Windows[i];
    }
    public void ResetBindings() => bindings.Clear();
    private Dictionary<Guid,WindowMatch> Resolve(Workspace workspace,IReadOnlyList<WindowInfo> live, bool conservative = false, IReadOnlyDictionary<Guid,WindowInfo>? draftBindings = null)
    {
        var resolved = workspace.Windows.ToDictionary(e => e.Id,e =>
        {
            bindings.TryGetValue((workspace.Id,e.Id),out var bound);
            if(draftBindings!=null && draftBindings.TryGetValue(e.Id,out var draftBound)) bound=draftBound;
            if(!conservative) return WindowMatcher.Resolve(e,bound,live);
            var exact=ExactWindowResolver.Resolve(e.Snapshot,bound,live);
            return new WindowMatch(exact.Window,exact.Window==null ? MatchStatus.NotFound : MatchStatus.Matched,exact.Reason);
        });
        // Never assign one real window to two entries in a single Workspace.
        var conflicts = resolved.Where(x => x.Value.Window != null).GroupBy(x => x.Value.Window!.Handle)
            .Where(g => g.Count()>1).SelectMany(g => g.Select(x => x.Key)).ToArray();
        foreach (var id in conflicts) resolved[id]=new(null,MatchStatus.Conflict,"다른 등록 항목과 같은 창을 가리켜 조작하지 않았습니다.");
        return resolved;
    }
    public void CommitDraftBindings(WorkspaceDraft draft)
    {
        var ids=draft.Workspace.Windows.Select(e=>e.Id).ToHashSet();
        foreach(var key in bindings.Keys.Where(k=>k.Workspace==draft.Workspace.Id && !ids.Contains(k.Entry)).ToArray()) bindings.Remove(key);
        foreach(var pair in draft.Bindings)
            if(ids.Contains(pair.Key)) bindings[(draft.Workspace.Id,pair.Key)]=pair.Value;
    }
    public void ForgetWorkspace(Guid id)
    {
        foreach(var key in bindings.Keys.Where(k=>k.Workspace==id).ToArray()) bindings.Remove(key);
    }
    public WorkspaceDraft AddWindows(WorkspaceDraft draft,IReadOnlyList<WindowInfo> selected)
    {
        if(draft.Workspace.Windows.Count+selected.Count>64) throw new ArgumentException("Workspace에는 최대 64개 창을 저장할 수 있습니다.");
        var existing=Resolve(draft.Workspace,desktop.Enumerate(),draftBindings:draft.Bindings);
        foreach(var chosen in selected)
        {
            if(existing.Values.Any(r=>r.Window is { } w && ExactWindowResolver.SameLiveWindow(w,chosen)))
                throw new InvalidOperationException($"이미 등록된 창입니다: {chosen.Title}");
            if(draft.Workspace.Windows.Any(e=>existing[e.Id].Window==null && e.Snapshot.Identity==chosen.Identity))
                throw new InvalidOperationException($"같은 등록 창인지 확인할 수 없습니다: {chosen.Title}. 기존 항목을 확인하세요.");
        }
        var added=Capture(draft.Workspace.Name,selected);
        var known=draft.Bindings.ToDictionary(p=>p.Key,p=>p.Value);
        for(int i=0;i<added.Workspace.Windows.Count;i++) known[added.Workspace.Windows[i].Id]=added.Windows[i];
        return new(draft.Workspace with { Windows=[..draft.Workspace.Windows,..added.Workspace.Windows] },known);
    }
    public WorkspaceRefreshResult CaptureCurrentLayout(WorkspaceDraft draft)
    {
        var results=new List<WorkspaceItemResult>();
        if(draft.Workspace.Windows.Count==0) return new(null,[new("Workspace","업데이트",OperationStatus.Failed,"먼저 창을 추가하세요.")]);
        var resolved=Resolve(draft.Workspace,desktop.Enumerate(),draftBindings:draft.Bindings);
        var snapshots=new List<WorkspaceWindow>(); var known=new Dictionary<Guid,WindowInfo>();
        foreach(var entry in draft.Workspace.Windows)
        {
            var match=resolved[entry.Id];
            if(match.Window==null)
            { results.Add(new(entry.DisplayName,"업데이트",OperationStatus.Failed,match.Reason)); continue; }
            try
            {
                var snapshot=desktop.Capture(match.Window);
                snapshots.Add(entry with { Snapshot=snapshot }); known[entry.Id]=match.Window;
                results.Add(new(entry.DisplayName,"업데이트",OperationStatus.Success,"현재 배치를 읽었습니다."));
            }
            catch(Exception ex) { results.Add(new(entry.DisplayName,"업데이트",OperationStatus.Failed,ex.Message)); }
        }
        // All-or-nothing: a missing window must not erase its saved placement or its launch settings.
        if(results.Any(r=>r.Status!=OperationStatus.Success)) return new(null,results);
        return new(new(draft.Workspace with { Windows=snapshots,UpdatedAt=DateTimeOffset.UtcNow },known),results);
    }
    public async Task<WorkspaceOpenResult> OpenAsync(Workspace target,IReadOnlyList<Workspace> all, CancellationToken cancellationToken = default)
    {
        if (!await gate.WaitAsync(0).ConfigureAwait(false))
            return new(target.Id,false,[new(target.Name,"전환",OperationStatus.Failed,"다른 Workspace 전환이 진행 중입니다.")]);
        var results = new List<WorkspaceItemResult>();
        using var deadline = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        deadline.CancelAfter(TimeSpan.FromSeconds(120));
        var token=deadline.Token;
        using var throttle=new SemaphoreSlim(4,4);
        var pending=new Dictionary<Guid,Task<WorkspaceItemResult>>();
        async Task<WorkspaceItemResult> RestoreEntryAsync(WorkspaceWindow entry,WindowMatch match)
        {
            bool entered=false;
            try
            {
                await throttle.WaitAsync(token).ConfigureAwait(false); entered=true;
                var outcome=await desktop.RestoreAsync(match.Window!,entry.Snapshot).ConfigureAwait(false);
                return new(entry.DisplayName,"복원",outcome.Status,match.Reason+" · "+outcome.Message);
            }
            catch(OperationCanceledException) { return new(entry.DisplayName,"복원",OperationStatus.Partial,"복원 대기를 중단했습니다."); }
            catch(Exception ex) { return new(entry.DisplayName,"복원",OperationStatus.Failed,ex.Message); }
            finally { if(entered) throttle.Release(); }
        }
        try
        {
            WorkspaceStore.Validate(new(1,0,null,all.ToList()));
            if (!all.Any(w => w.Id==target.Id)) throw new ArgumentException("Workspace가 목록에 없습니다.");
            var live = desktop.Enumerate();
            var resolved = Resolve(target,live);
            var reserved=resolved.Values.Where(m=>m.Window!=null).Select(m=>m.Window!.Handle).ToHashSet();
            // Already-open windows need not wait for another app's startup timeout.
            foreach(var entry in target.Windows)
                if(resolved[entry.Id].Window!=null) pending[entry.Id]=RestoreEntryAsync(entry,resolved[entry.Id]);
            if(launchCoordinator!=null)
                foreach(var entry in target.Windows)
                {
                    token.ThrowIfCancellationRequested();
                    if(resolved[entry.Id].Window!=null || resolved[entry.Id].Status==MatchStatus.Conflict) continue;
                    if(entry.Launch is not { Kind: not LaunchKind.None, Behavior: LaunchBehavior.LaunchIfMissing }) continue;
                    try
                    {
                        var found=await launchCoordinator.LaunchAndWaitAsync(target.Id,entry,reserved,token).ConfigureAwait(false);
                        resolved[entry.Id]=found;
                        if(found.Window!=null)
                        { reserved.Add(found.Window.Handle); pending[entry.Id]=RestoreEntryAsync(entry,found); }
                    }
                    catch(OperationCanceledException) { throw; }
                    catch(Exception ex) { resolved[entry.Id]=new(null,MatchStatus.NotFound,"실행 실패: "+ex.Message); }
                }
            token.ThrowIfCancellationRequested();
            var work=target.Windows.Select(entry=>pending.TryGetValue(entry.Id,out var task) ? task :
                Task.FromResult(new WorkspaceItemResult(entry.DisplayName,"복원",OperationStatus.Failed,resolved[entry.Id].Reason))).ToArray();
            results.AddRange(await Task.WhenAll(work).ConfigureAwait(false));
            for(int i=0;i<target.Windows.Count;i++)
                if(results[i].Status==OperationStatus.Success && resolved[target.Windows[i].Id].Window is { } window)
                    bindings[(target.Id,target.Windows[i].Id)]=window;
            if (results.Any(r=>r.Status!=OperationStatus.Success))
            {
                results.Add(new(target.Name,"전환",OperationStatus.Partial,"일부 창이 복원되지 않아 다른 Workspace 창 최소화를 생략했습니다."));
                return new(target.Id,false,results);
            }
            token.ThrowIfCancellationRequested();
            // Refresh before minimizing. A process may have exited during target restoration.
            live = desktop.Enumerate();
            var targetWindows = resolved.Values.Select(x=>x.Window!).ToArray();
            if (targetWindows.Any(w=>!live.Any(now=>ExactWindowResolver.SameLiveWindow(w,now))))
            {
                results.Add(new(target.Name,"전환",OperationStatus.Failed,"복원 중 대상 창이 닫혀 다른 창 최소화를 생략했습니다."));
                return new(target.Id,false,results);
            }
            var protectedHandles = targetWindows.Select(w=>w.Handle).ToHashSet();
            var others = new Dictionary<nint,WindowInfo>();
            foreach(var other in all.Where(w=>w.Id!=target.Id))
                foreach(var match in Resolve(other,live,conservative:true).Values)
                    if(match.Window is { } w && !protectedHandles.Contains(w.Handle)) others.TryAdd(w.Handle,w);
            foreach(var w in others.Values)
            {
                token.ThrowIfCancellationRequested();
                if(w.State==WindowState.Minimized) continue;
                try
                {
                    var outcome = await desktop.MinimizeAsync(w).ConfigureAwait(false);
                    results.Add(new(w.Title,"다른 Workspace 최소화",outcome.Status,outcome.Message));
                }
                catch(Exception ex) { results.Add(new(w.Title,"다른 Workspace 최소화",OperationStatus.Failed,ex.Message)); }
            }
            return new(target.Id,results.All(r=>r.Status==OperationStatus.Success),results);
        }
        catch(OperationCanceledException)
        {
            if(results.Count==0) results.AddRange(await Task.WhenAll(pending.Values).ConfigureAwait(false));
            results.Add(new(target.Name,"전환",OperationStatus.Partial,"전환 대기를 중단했습니다. 이미 실행한 앱이나 복원한 창은 그대로 둡니다."));
            return new(target.Id,false,results);
        }
        catch(Exception ex)
        { results.Add(new(target.Name,"전환",OperationStatus.Failed,ex.Message)); return new(target.Id,false,results); }
        finally { await Task.WhenAll(pending.Values).ConfigureAwait(false); gate.Release(); }
    }
}
