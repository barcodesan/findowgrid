using findowgrid.Engine.Models;
namespace findowgrid.Engine.Services;
// Small seam for verifying switch policy without touching real Windows windows.
public interface IWindowDesktop
{
    IReadOnlyList<WindowInfo> Enumerate();
    WindowSnapshot Capture(WindowInfo window);
    Task<WindowOperationResult> RestoreAsync(WindowInfo window, WindowSnapshot snapshot);
    Task<WindowOperationResult> MinimizeAsync(WindowInfo window);
}
