using findowgrid.Engine.Models;
namespace findowgrid.Engine.Services;
// Owns registration lifetime, independent of the UI and native message pump.
public sealed class HotkeyBindings(Func<int,HotkeySpec,bool> register,Action<int> unregister) : IDisposable
{
    private readonly Dictionary<HotkeySpec,(int Id,Guid Workspace)> active=[];
    private int nextId=100;
    public Guid? Find(int id) => active.Values.Where(v=>v.Id==id).Select(v=>(Guid?)v.Workspace).FirstOrDefault();
    public void Apply(IEnumerable<Workspace> workspaces)
    {
        var wanted=workspaces.Where(w=>w.Hotkey!=null).ToDictionary(w=>w.Hotkey!,w=>w.Id);
        var added=new List<HotkeySpec>();
        try
        {
            foreach(var pair in wanted)
            {
                pair.Key.Validate();
                if(active.ContainsKey(pair.Key)) continue;
                int id=nextId++;
                if(id>0xBFFF || !register(id,pair.Key))
                    throw new InvalidOperationException($"{pair.Key}: 다른 앱 또는 Windows가 사용하는 단축키입니다. 다른 조합을 선택하세요.");
                active.Add(pair.Key,(id,pair.Value)); added.Add(pair.Key);
            }
        }
        catch { foreach(var key in added) Remove(key); throw; }
        foreach(var key in active.Keys.ToArray())
            if(!wanted.ContainsKey(key)) Remove(key); else active[key]=(active[key].Id,wanted[key]);
    }
    public Action Change(Workspace workspace)
    {
        // Only change this Workspace; unrelated startup conflicts must not block editing.
        var before=active.Select(p=>new Workspace(p.Value.Workspace,"",default,[],p.Key)).ToArray();
        Apply(before.Where(w=>w.Id!=workspace.Id).Append(workspace));
        return ()=>Apply(before);
    }
    public void RemoveWorkspace(Guid id)
    { foreach(var key in active.Where(p=>p.Value.Workspace==id).Select(p=>p.Key).ToArray()) Remove(key); }
    private void Remove(HotkeySpec key) { unregister(active[key].Id); active.Remove(key); }
    public void Dispose() { foreach(var key in active.Keys.ToArray()) Remove(key); }
}
