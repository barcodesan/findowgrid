using System.ComponentModel;
using System.Runtime.InteropServices;
using findowgrid.Engine.Interop;
using findowgrid.Engine.Models;
using N = findowgrid.Engine.Interop.NativeMethods;
namespace findowgrid.Engine.Services;
public sealed class MonitorService
{
    public IReadOnlyList<MonitorSnapshot> GetAll()
    {
        using var scope = new DpiScope();
        var result = new List<MonitorSnapshot>();
        Exception? failure = null;
        N.EnumDisplayMonitors(0, 0, (nint h, nint dc, ref N.RECT r, nint d) =>
        { try { result.Add(Read(h)); } catch (Exception ex) { failure = ex; return false; } return true; }, 0);
        if (failure != null) throw failure;
        if (result.Count == 0) throw new InvalidOperationException("사용 가능한 모니터가 없습니다.");
        return result;
    }
    internal static MonitorSnapshot ForWindow(nint hwnd) => Read(N.MonitorFromWindow(hwnd, 2));
    internal static MonitorSnapshot Read(nint handle)
    {
        var info = new N.MONITORINFOEX { Size = (uint)Marshal.SizeOf<N.MONITORINFOEX>(), Device = "" };
        if (!N.GetMonitorInfo(handle, ref info)) throw new Win32Exception(Marshal.GetLastWin32Error());
        var paths = new List<string>();
        for(uint i=0;i<64;i++)
        {
            var device=new DisplayDevice { Size=Marshal.SizeOf<DisplayDevice>(), Name="", Description="", Id="", Key="" };
            if(!EnumDisplayDevices(info.Device,i,ref device,1)) break;
            if((device.Flags&1)!=0 && !string.IsNullOrWhiteSpace(device.Id)) paths.Add(device.Id);
        }
        return new(info.Device, FromNative(info.Monitor), FromNative(info.Work), (info.Flags & 1) != 0,
            paths.Count==1 ? paths[0] : null);
    }
    [StructLayout(LayoutKind.Sequential,CharSet=CharSet.Unicode)]
    private struct DisplayDevice
    {
        public int Size;
        [MarshalAs(UnmanagedType.ByValTStr,SizeConst=32)] public string Name;
        [MarshalAs(UnmanagedType.ByValTStr,SizeConst=128)] public string Description;
        public uint Flags;
        [MarshalAs(UnmanagedType.ByValTStr,SizeConst=128)] public string Id;
        [MarshalAs(UnmanagedType.ByValTStr,SizeConst=128)] public string Key;
    }
    [DllImport("user32.dll",CharSet=CharSet.Unicode,EntryPoint="EnumDisplayDevicesW")]
    [return:MarshalAs(UnmanagedType.Bool)]
    private static extern bool EnumDisplayDevices(string name,uint index,ref DisplayDevice device,uint flags);
    internal static PixelRect FromNative(N.RECT r) => new(r.Left, r.Top, r.Right-r.Left, r.Bottom-r.Top);
    internal static N.RECT ToNative(PixelRect r) => new() { Left=r.X, Top=r.Y, Right=r.X+r.Width, Bottom=r.Y+r.Height };
}
