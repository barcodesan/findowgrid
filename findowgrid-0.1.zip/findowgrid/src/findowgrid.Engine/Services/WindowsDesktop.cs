using findowgrid.Engine.Models;
namespace findowgrid.Engine.Services;
public sealed class WindowsDesktop : IWindowDesktop
{
    private readonly WindowEnumerator windows = new();
    private readonly PlacementService placement = new();
    public IReadOnlyList<WindowInfo> Enumerate() => windows.Enumerate(includeExtra: true);
    public WindowSnapshot Capture(WindowInfo window) => placement.Capture(window);
    public Task<WindowOperationResult> RestoreAsync(WindowInfo window, WindowSnapshot snapshot) => placement.RestoreAsync(window,snapshot);
    public Task<WindowOperationResult> MinimizeAsync(WindowInfo window) => placement.MinimizeAsync(window);
}
