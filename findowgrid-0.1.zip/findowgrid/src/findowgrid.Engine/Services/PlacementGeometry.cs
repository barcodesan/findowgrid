using findowgrid.Engine.Models;
namespace findowgrid.Engine.Services;
public static class PlacementGeometry
{
    public static PixelRect Clamp(PixelRect r, PixelRect work)
    {
        if (!r.IsValid || !work.IsValid) throw new ArgumentException("유효하지 않은 배치입니다.");
        int w = Math.Min(r.Width, work.Width), h = Math.Min(r.Height, work.Height);
        return new(Math.Clamp(r.X, work.X, work.X + work.Width-w), Math.Clamp(r.Y, work.Y, work.Y+work.Height-h), w, h);
    }
    public static PixelRect Map(PixelRect r, PixelRect oldWork, PixelRect newWork)
    {
        if (!r.IsValid || !oldWork.IsValid || !newWork.IsValid) throw new ArgumentException("유효하지 않은 배치입니다.");
        if (oldWork == newWork) return Clamp(r, newWork);
        double sx = (double)newWork.Width/oldWork.Width, sy = (double)newWork.Height/oldWork.Height;
        return Clamp(new(newWork.X+(int)Math.Round((r.X-oldWork.X)*sx), newWork.Y+(int)Math.Round((r.Y-oldWork.Y)*sy),
            Math.Max(1,(int)Math.Round(r.Width*sx)), Math.Max(1,(int)Math.Round(r.Height*sy))), newWork);
    }
    public static FrameInsets Insets(PixelRect outer, PixelRect visible)
    {
        // Fail closed to zero if an app reports unusual/non-client rectangles.
        var i = new FrameInsets(visible.X-outer.X,visible.Y-outer.Y,
            outer.X+outer.Width-visible.X-visible.Width,outer.Y+outer.Height-visible.Y-visible.Height);
        return new[]{i.Left,i.Top,i.Right,i.Bottom}.All(v=>v>=0 && v<=128) ? i : FrameInsets.Zero;
    }
    public static PixelRect OuterFromVisible(PixelRect r, FrameInsets i) =>
        new(r.X-i.Left,r.Y-i.Top,r.Width+i.Left+i.Right,r.Height+i.Top+i.Bottom);
    public static PixelRect VisibleFromOuter(PixelRect r, FrameInsets i) =>
        new(r.X+i.Left,r.Y+i.Top,Math.Max(1,r.Width-i.Left-i.Right),Math.Max(1,r.Height-i.Top-i.Bottom));
    public static PixelRect MapOuter(PixelRect r, PixelRect oldWork, PixelRect newWork, FrameInsets insets) =>
        OuterFromVisible(Map(VisibleFromOuter(r,insets),oldWork,newWork),insets);
    public static bool Near(PixelRect a, PixelRect b, int tolerance = 8) =>
        Math.Abs((long)a.X-b.X)<=tolerance && Math.Abs((long)a.Y-b.Y)<=tolerance &&
        Math.Abs((long)a.Width-b.Width)<=tolerance && Math.Abs((long)a.Height-b.Height)<=tolerance;
}
