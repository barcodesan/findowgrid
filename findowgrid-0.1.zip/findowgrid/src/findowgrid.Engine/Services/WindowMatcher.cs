using System.Text.RegularExpressions;
using findowgrid.Engine.Models;
namespace findowgrid.Engine.Services;
public static class WindowMatcher
{
    private static string Normalize(string s) => Regex.Replace(s.Trim().TrimStart('*','●',' '),@"\s+"," ");
    public static WindowMatch Resolve(WorkspaceWindow entry,WindowInfo? binding,IReadOnlyList<WindowInfo> live,
        ISet<nint>? reserved=null,LaunchContext? launch=null)
    {
        var available=live.Where(w=>reserved==null || !reserved.Contains(w.Handle)).ToArray();
        if(binding!=null && launch==null)
        {
            var bound=available.FirstOrDefault(w=>ExactWindowResolver.SameLiveWindow(binding,w));
            if(bound!=null) return new(bound,MatchStatus.Matched,"동일한 실행 창");
        }
        var id=entry.Snapshot.Identity;
        if(string.IsNullOrWhiteSpace(id.ExecutablePath))
            return new(null,MatchStatus.NotFound,"저장된 실행 경로가 없어 재식별할 수 없습니다.");
        var ranked=new List<(WindowInfo Window,int Score)>();
        foreach(var w in available)
        {
            // A path/class contradiction is never outweighed by a similar title.
            if(!string.Equals(w.Identity.ExecutablePath,id.ExecutablePath,StringComparison.OrdinalIgnoreCase) ||
                !string.Equals(w.Identity.ProcessName,id.ProcessName,StringComparison.OrdinalIgnoreCase) || w.Identity.ClassName!=id.ClassName) continue;
            bool fresh=launch!=null && !launch.Before.Any(old=>ExactWindowResolver.SameLiveWindow(old,w));
            bool titleChanged=launch!=null && launch.Before.Any(old=>ExactWindowResolver.SameLiveWindow(old,w) && old.Title!=w.Title);
            if(launch!=null && BrowserLaunchPolicy.RequiresFreshWindow(entry.Launch) && !fresh) continue;
            if(launch!=null && !fresh && !titleChanged) continue;
            int score=90; bool explicitPattern=!string.IsNullOrWhiteSpace(entry.Match?.TitleContains);
            if(explicitPattern)
            {
                if(!w.Title.Contains(entry.Match!.TitleContains!,StringComparison.OrdinalIgnoreCase)) continue;
                score+=25;
            }
            else if(!string.IsNullOrWhiteSpace(id.Title) && w.Title==id.Title) score+=40;
            else if(id.Title.Length>=4 && Normalize(w.Title)==Normalize(id.Title)) score+=35;
            // Only a newly-created window of the process we just started may omit a title match.
            else if(fresh && !BrowserLaunchPolicy.RequiresFreshWindow(entry.Launch) && launch!.Ticket.ProcessId==w.ProcessId) score+=20;
            else continue;
            ranked.Add((w,score));
        }
        ranked=ranked.OrderByDescending(x=>x.Score).ToList();
        if(ranked.Count==0) return new(null,MatchStatus.NotFound,"신뢰할 수 있는 창을 찾지 못했습니다. 제목 조건 또는 실행 설정을 확인하세요.");
        if(ranked.Count>1 && ranked[0].Score-ranked[1].Score<20)
            return new(null,MatchStatus.Ambiguous,"비슷한 후보가 여러 개여서 임의로 선택하지 않았습니다.");
        return new(ranked[0].Window,MatchStatus.Matched,$"경로·프로세스·class 및 제목/실행 근거 일치 ({ranked[0].Score})");
    }
}
