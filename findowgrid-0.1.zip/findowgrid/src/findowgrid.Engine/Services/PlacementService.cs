using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.InteropServices;
using findowgrid.Engine.Interop;
using findowgrid.Engine.Models;
using N = findowgrid.Engine.Interop.NativeMethods;
namespace findowgrid.Engine.Services;
public sealed class PlacementService
{
    private readonly WindowEnumerator windows = new();
    private readonly MonitorService monitors = new();
    public WindowSnapshot Capture(WindowInfo selected)
    {
        var w = windows.Validate(selected);
        var result = new WindowSnapshot(1, DateTimeOffset.UtcNow, w.Identity, w.NormalBoundsScreenPx,
            w.State, w.RestoreToMaximized, w.Monitor, w.WindowDpi, w.VisibleBoundsPx);
        Storage.SnapshotStore.Validate(result);
        return result;
    }
    public Task<WindowOperationResult> TestMoveAsync(WindowInfo selected) => Task.Run(async () =>
    {
        try
        {
            var current = windows.Validate(selected);
            var work = current.Monitor.WorkArea;
            // A visibly different, bounded position, without touching any other window.
            int w = Math.Max(1, (int)(work.Width * .60)), h = Math.Max(1, (int)(work.Height * .65));
            int x = work.X + (int)(work.Width * .06), y = work.Y + (int)(work.Height * .08);
            if (Math.Abs(current.NormalBoundsScreenPx.X-x)<20) x = work.X+work.Width-w;
            return await ApplyAsync(selected, new(x,y,w,h), WindowState.Normal, false, "테스트 이동");
        }
        catch (Exception ex) when (IsExpected(ex)) { return new(OperationStatus.Failed, ex.Message); }
    });
    public Task<WindowOperationResult> RestoreAsync(WindowInfo selected, WindowSnapshot snapshot) => Task.Run(async () =>
    {
        try
        {
            Storage.SnapshotStore.Validate(snapshot);
            var current = windows.Validate(selected);
            // The caller has selected or resolved this exact target. Launching stays outside the placement engine.
            if (!Compatible(current.Identity, snapshot.Identity))
                return new(OperationStatus.Failed, "저장한 앱과 선택한 앱이 다릅니다. 올바른 창을 선택하세요.");
            var all = monitors.GetAll();
            // DeviceName is only a Phase 1 hint, not a permanent monitor identity.
            var target = MonitorSelector.Select(snapshot.Monitor, all);
            PixelRect? desiredVisible = snapshot.State == WindowState.Normal && snapshot.VisibleBoundsPx is { } savedVisible
                ? PlacementGeometry.Map(savedVisible,snapshot.Monitor.WorkArea,target.WorkArea) : null;
            var insets = current.VisibleBoundsPx is { } v ? PlacementGeometry.Insets(current.OuterBoundsPx,v)
                : snapshot.VisibleBoundsPx is { } sv ? PlacementGeometry.Insets(snapshot.NormalBoundsScreenPx,sv) : FrameInsets.Zero;
            var rect = desiredVisible is { } desired ? PlacementGeometry.OuterFromVisible(desired,insets)
                : PlacementGeometry.MapOuter(snapshot.NormalBoundsScreenPx,snapshot.Monitor.WorkArea,target.WorkArea,insets);
            return await ApplyAsync(selected, rect, snapshot.State, snapshot.RestoreToMaximized, "복원", desiredVisible);
        }
        catch (Exception ex) when (IsExpected(ex)) { return new(OperationStatus.Failed, ex.Message); }
    });
    public Task<WindowOperationResult> MinimizeAsync(WindowInfo selected) => Task.Run(async () =>
    {
        try
        {
            var current = windows.Validate(selected);
            if (current.State == WindowState.Minimized) return new WindowOperationResult(OperationStatus.Success,"이미 최소화되어 있습니다.");
            return await ApplyAsync(selected,current.NormalBoundsScreenPx,WindowState.Minimized,
                current.State == WindowState.Maximized,"최소화");
        }
        catch (Exception ex) when (IsExpected(ex)) { return new(OperationStatus.Failed,ex.Message); }
    });
    private static bool Compatible(WindowIdentity a, WindowIdentity b) =>
        a.ClassName == b.ClassName && string.Equals(a.ProcessName,b.ProcessName,StringComparison.OrdinalIgnoreCase) &&
        (b.ExecutablePath == null || string.Equals(a.ExecutablePath,b.ExecutablePath,StringComparison.OrdinalIgnoreCase));
    private static bool IsExpected(Exception ex) => ex is Win32Exception or InvalidOperationException or ArgumentException or System.IO.InvalidDataException;
    private async Task<WindowOperationResult> ApplyAsync(WindowInfo selected, PixelRect rect, WindowState state, bool restoreMax, string label, PixelRect? desiredVisible = null)
    {
        IssuePlacement(selected, rect, state, restoreMax);
        // Async Win32 placement is only queued; verify actual results within a bounded interval.
        var clock = Stopwatch.StartNew();
        WindowInfo? actual = null;
        int stable = 0, corrections = 0;
        while (clock.Elapsed < TimeSpan.FromSeconds(2))
        {
            await Task.Delay(100).ConfigureAwait(false);
            actual = windows.Validate(selected);
            var observed = state == WindowState.Normal ? actual.OuterBoundsPx : actual.NormalBoundsScreenPx;
            if (desiredVisible is { } desired && actual.State == WindowState.Normal && actual.VisibleBoundsPx is { } visible)
            {
                observed = visible;
                if (!PlacementGeometry.Near(visible,desired,2) && corrections < 2)
                {
                    // DWM margins can change after crossing a DPI boundary. Measure on the destination monitor.
                    rect = PlacementGeometry.OuterFromVisible(desired,PlacementGeometry.Insets(actual.OuterBoundsPx,visible));
                    SetNormalBounds(selected,rect);
                    corrections++; stable=0; continue;
                }
            }
            bool match = actual.State == state && PlacementGeometry.Near(observed, desiredVisible ?? rect, desiredVisible == null ? 8 : 2) &&
                (state != WindowState.Minimized || actual.RestoreToMaximized == restoreMax);
            stable = match ? stable+1 : 0;
            if (stable >= 3) return new(OperationStatus.Success, $"{label} 완료 — 위치와 상태를 확인했습니다.", desiredVisible ?? rect, observed);
        }
        return new(OperationStatus.Partial, $"{label} 요청 후 목표 배치를 확인하지 못했습니다. 앱의 크기 제한·권한·응답 상태를 확인하세요.",
            desiredVisible ?? rect, actual == null ? null : desiredVisible != null ? actual.VisibleBoundsPx : state == WindowState.Normal ? actual.OuterBoundsPx : actual.NormalBoundsScreenPx);
    }
    private void SetNormalBounds(WindowInfo selected, PixelRect rect)
    {
        using var scope = new DpiScope();
        windows.Validate(selected);
        if (!N.SetWindowPos(selected.Handle,0,rect.X,rect.Y,rect.Width,rect.Height,0x0004|0x0010|0x0200|0x4000))
            throw new Win32Exception(Marshal.GetLastWin32Error());
    }
    private void IssuePlacement(WindowInfo selected, PixelRect rect, WindowState state, bool restoreMax)
    {
        using var scope = new DpiScope();
        windows.Validate(selected);
        var nativeRect = MonitorService.ToNative(rect);
        var monitor = MonitorService.Read(N.MonitorFromRect(ref nativeRect,2));
        var placement = N.WINDOWPLACEMENT.Create();
        if (!N.GetWindowPlacement(selected.Handle,ref placement)) throw new Win32Exception(Marshal.GetLastWin32Error());
        bool tool = ((long)N.GetWindowLongPtr(selected.Handle,-20)&0x80)!=0;
        var workspaceRect = tool ? rect : rect with { X=rect.X-(monitor.WorkArea.X-monitor.Bounds.X), Y=rect.Y-(monitor.WorkArea.Y-monitor.Bounds.Y) };
        placement.NormalPosition = MonitorService.ToNative(workspaceRect);
        placement.Flags = 4 | (restoreMax && state == WindowState.Minimized ? 2u : 0u); // ASYNC + RESTORETOMAXIMIZED
        // SW_SHOWNOACTIVATE and SW_SHOWMINNOACTIVE avoid activation for normal/minimized.
        // Windows may activate a maximized window; no foreground bypass is attempted.
        placement.ShowCmd = state switch { WindowState.Maximized => 3u, WindowState.Minimized => 7u, _ => 4u };
        if (!N.SetWindowPlacement(selected.Handle,in placement)) throw new Win32Exception(Marshal.GetLastWin32Error());
        if (state == WindowState.Normal && !N.SetWindowPos(selected.Handle,0,rect.X,rect.Y,rect.Width,rect.Height,
            0x0004 | 0x0010 | 0x0200 | 0x4000)) // NOZORDER | NOACTIVATE | NOOWNERZORDER | ASYNCWINDOWPOS
            throw new Win32Exception(Marshal.GetLastWin32Error());
    }
}
