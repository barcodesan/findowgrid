using findowgrid.Engine.Models;
namespace findowgrid.Engine.Services;
public sealed record WindowResolution(WindowInfo? Window, string Reason);
public static class ExactWindowResolver
{
    public static bool SameLiveWindow(WindowInfo saved, WindowInfo current) =>
        saved.Handle == current.Handle && saved.ProcessId == current.ProcessId &&
        saved.Identity.ClassName == current.Identity.ClassName &&
        (!saved.ProcessStartTicks.HasValue || saved.ProcessStartTicks == current.ProcessStartTicks) &&
        (saved.Identity.ExecutablePath == null || string.Equals(saved.Identity.ExecutablePath,current.Identity.ExecutablePath,StringComparison.OrdinalIgnoreCase));

    public static WindowResolution Resolve(WindowSnapshot snapshot, WindowInfo? binding, IReadOnlyList<WindowInfo> live)
    {
        if (binding != null)
        {
            var bound = live.FirstOrDefault(w => SameLiveWindow(binding,w));
            if (bound != null) return new(bound,"현재 실행 중인 등록 창");
        }
        // Phase 2 fallback is intentionally exact, not heuristic. Never use process name alone.
        var id = snapshot.Identity;
        if (string.IsNullOrWhiteSpace(id.ExecutablePath) || string.IsNullOrWhiteSpace(id.Title))
            return new(null,"경로 또는 제목이 없어 자동 연결할 수 없습니다. 창을 선택해 새 Workspace로 저장하세요.");
        var matches = live.Where(w => string.Equals(w.Identity.ExecutablePath,id.ExecutablePath,StringComparison.OrdinalIgnoreCase)
            && string.Equals(w.Identity.ProcessName,id.ProcessName,StringComparison.OrdinalIgnoreCase)
            && w.Identity.ClassName == id.ClassName && w.Identity.Title == id.Title).Take(2).ToArray();
        return matches.Length switch
        {
            1 => new(matches[0],"경로·프로세스·class·제목 완전 일치"),
            0 => new(null,"일치하는 열린 창이 없습니다. 앱을 직접 열고 저장 당시 제목을 확인하세요."),
            _ => new(null,"동일한 후보가 여러 개여서 조작하지 않았습니다.")
        };
    }
}
