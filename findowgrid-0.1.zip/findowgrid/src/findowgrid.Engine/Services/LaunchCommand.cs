using System.Diagnostics;
using findowgrid.Engine.Models;
namespace findowgrid.Engine.Services;
public static class LaunchCommand
{
    public static ProcessStartInfo Create(LaunchSpec spec)
    {
        LaunchValidation.Validate(spec);
        if(spec.Kind==LaunchKind.None) throw new InvalidOperationException("실행 정보가 없습니다.");
        if(spec.Kind==LaunchKind.Url && string.IsNullOrWhiteSpace(spec.BrowserPath))
            return new(spec.Url!) { UseShellExecute=true };
        var path=spec.Kind==LaunchKind.Application ? spec.ExecutablePath : spec.BrowserPath;
        var info=new ProcessStartInfo(path!) { UseShellExecute=false };
        if(!string.IsNullOrWhiteSpace(spec.WorkingDirectory)) info.WorkingDirectory=spec.WorkingDirectory;
        foreach(var arg in spec.Arguments ?? []) info.ArgumentList.Add(arg);
        if(spec.Kind==LaunchKind.Url) info.ArgumentList.Add(spec.Url!);
        return info;
    }
}
