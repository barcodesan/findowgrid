using findowgrid.Engine.Models;
namespace findowgrid.Engine.Services;
public static class MonitorSelector
{
    public static MonitorSnapshot Select(MonitorSnapshot saved, IReadOnlyList<MonitorSnapshot> current)
    {
        if(current.Count==0) throw new InvalidOperationException("사용 가능한 모니터가 없습니다.");
        var matches=current.Where(m=> !string.IsNullOrEmpty(saved.DevicePath)
            ? string.Equals(m.DevicePath,saved.DevicePath,StringComparison.OrdinalIgnoreCase)
            : m.DeviceName==saved.DeviceName && m.Bounds==saved.Bounds).ToArray();
        return matches.Length==1 ? matches[0] : current.FirstOrDefault(m=>m.IsPrimary) ?? current[0];
    }
}
