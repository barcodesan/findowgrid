namespace findowgrid.Engine.Models;

public sealed record WorkspaceWindow(Guid Id, WindowSnapshot Snapshot, LaunchSpec? Launch = null, MatchRules? Match = null)
{
    public string DisplayName => string.IsNullOrWhiteSpace(Snapshot.Identity.Title)
        ? Snapshot.Identity.ProcessName : Snapshot.Identity.Title;
}
public sealed record Workspace(Guid Id, string Name, DateTimeOffset UpdatedAt, List<WorkspaceWindow> Windows, HotkeySpec? Hotkey = null)
{
    public string Summary => $"{Name} · {Windows.Count}개 창";
}
public sealed record WorkspaceDocument(int SchemaVersion, long Revision, Guid? LastWorkspaceId, List<Workspace> Workspaces)
{
    public static WorkspaceDocument Empty => new(2, 0, null, []);
}
public sealed record CapturedWorkspace(Workspace Workspace, IReadOnlyList<WindowInfo> Windows);
public sealed record WorkspaceItemResult(string WindowName, string Action, OperationStatus Status, string Message);
public sealed record WorkspaceOpenResult(Guid WorkspaceId, bool Completed, IReadOnlyList<WorkspaceItemResult> Items);
