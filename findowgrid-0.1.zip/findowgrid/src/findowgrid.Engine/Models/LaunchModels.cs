namespace findowgrid.Engine.Models;
public enum LaunchKind { None, Application, Url }
public enum BrowserWindowMode { Automatic, NewWindow, BrowserDefault }
public enum LaunchBehavior { ReuseOnly, LaunchIfMissing }
public sealed record LaunchSpec(LaunchKind Kind, string? ExecutablePath = null, List<string>? Arguments = null,
    string? WorkingDirectory = null, string? Url = null, string? BrowserPath = null,
    LaunchBehavior Behavior = LaunchBehavior.LaunchIfMissing, int WaitSeconds = 20, BrowserWindowMode BrowserWindow = BrowserWindowMode.Automatic);
public sealed record MatchRules(string? TitleContains = null);
public sealed record LaunchTicket(uint? ProcessId, string Message);
public sealed record LaunchContext(IReadOnlyList<WindowInfo> Before, LaunchTicket Ticket);
public enum MatchStatus { Matched, NotFound, Ambiguous, Conflict }
public sealed record WindowMatch(WindowInfo? Window, MatchStatus Status, string Reason);
