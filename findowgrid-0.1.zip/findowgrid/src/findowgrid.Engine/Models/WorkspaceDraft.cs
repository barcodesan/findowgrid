namespace findowgrid.Engine.Models;
// Draft bindings are transient and are never serialized into the Workspace document.
public sealed record WorkspaceDraft(Workspace Workspace, IReadOnlyDictionary<Guid,WindowInfo> Bindings)
{
    public static WorkspaceDraft FromCapture(CapturedWorkspace capture) => new(capture.Workspace,
        capture.Workspace.Windows.Select((e,i)=>(e.Id,Window:capture.Windows[i])).ToDictionary(x=>x.Id,x=>x.Window));
}
public sealed record WorkspaceRefreshResult(WorkspaceDraft? Draft,IReadOnlyList<WorkspaceItemResult> Items)
{
    public bool Succeeded => Draft!=null;
}
