namespace findowgrid.Engine.Models;

public enum WindowState { Normal, Minimized, Maximized }
public sealed record PixelRect(int X, int Y, int Width, int Height)
{
    public bool IsValid => Width > 0 && Height > 0 && Width <= 100000 && Height <= 100000
        && Math.Abs((long)X) <= 1000000 && Math.Abs((long)Y) <= 1000000;
}
public sealed record MonitorSnapshot(string DeviceName, PixelRect Bounds, PixelRect WorkArea, bool IsPrimary, string? DevicePath = null);
public sealed record WindowIdentity(string ProcessName, string? ExecutablePath, string ClassName, string Title);
// HWND and process lifetime are deliberately not part of the persisted snapshot.
public sealed record WindowInfo(nint Handle, uint ProcessId, long? ProcessStartTicks,
    WindowIdentity Identity, PixelRect OuterBoundsPx, PixelRect NormalBoundsScreenPx,
    WindowState State, bool RestoreToMaximized, MonitorSnapshot Monitor, uint WindowDpi,
    string? Diagnostic, PixelRect? VisibleBoundsPx = null)
{
    public string AppName => Identity.ProcessName;
    public string Title => Identity.Title;
    public string Details => $"PID {ProcessId} | {Identity.ClassName} | {OuterBoundsPx} | DPI {WindowDpi}\n{Identity.ExecutablePath ?? "경로 조회 불가"}\n{Diagnostic}";
}
public sealed record WindowSnapshot(int SchemaVersion, DateTimeOffset SavedAt, WindowIdentity Identity,
    PixelRect NormalBoundsScreenPx, WindowState State, bool RestoreToMaximized,
    MonitorSnapshot Monitor, uint WindowDpi, PixelRect? VisibleBoundsPx = null);
public enum OperationStatus { Success, Partial, Failed }
public sealed record WindowOperationResult(OperationStatus Status, string Message, PixelRect? Expected = null, PixelRect? Actual = null);

public sealed record FrameInsets(int Left, int Top, int Right, int Bottom)
{
    public static FrameInsets Zero => new(0,0,0,0);
}
