namespace findowgrid.Engine.Models;
public sealed record HotkeySpec(uint Modifiers, uint Key)
{
    public void Validate()
    {
        if (Modifiers == 0 || (Modifiers & ~15u) != 0 || !(Key is >= 48 and <= 57 or >= 65 and <= 90 or >= 112 and <= 122))
            throw new InvalidDataException("단축키는 보조키와 숫자·영문자·F1~F11을 조합하세요.");
    }
    public override string ToString() => string.Join(" + ", new[] {
        (Modifiers&8)!=0?"Win":null,(Modifiers&2)!=0?"Ctrl":null,
        (Modifiers&1)!=0?"Alt":null,(Modifiers&4)!=0?"Shift":null,
        Key>=112 ? $"F{Key-111}" : ((char)Key).ToString() }.Where(s=>s!=null));
}
