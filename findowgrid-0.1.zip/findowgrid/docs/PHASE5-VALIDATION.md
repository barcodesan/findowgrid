# Phase 5 검증

- .NET SDK 10.0.401 / WindowsDesktop targeting pack 10.0.12, Linux에서 Windows 대상 교차 빌드.
- Release 빌드: 오류 0, 경고 0.
- 자동 검사: 140개 통과. 이전 110개 회귀 + Phase 5 30개.
- Phase 5: 모니터 장치 식별·화면 번호/해상도 변경·분리/모호성/legacy fallback, 단축키 유효성·JSON 저장/제거·중복 방지, 등록 실패 rollback·기존 키 보존·등록 소유권 변경·삭제/종료 해제·오래된 메시지 무시.
- 네이티브 등록 자체는 테스트 대역을 이용했습니다. 실제 RegisterHotKey, NotifyIcon, 로그인 자동 실행, 다중 DPI 디스플레이, WPF 렌더링, HTS 동작은 Linux에서 실행하지 않았습니다.
- Windows 실기 검증 항목은 WINDOWS-TEST-CHECKLIST.md. 자동 검사 통과는 실기 성공 보장이 아닙니다.
- 저장 파일 schema 1/2 읽기 호환. Phase 5 추가 필드는 선택 사항입니다. 이전 버전으로 다시 저장하면 새 필드가 사라질 수 있으므로 다운그레이드 전 JSON을 복사해 보관하세요.

참고한 공식 API 문서:
- https://learn.microsoft.com/windows/win32/api/winuser/nf-winuser-enumdisplaydevicesw
- https://learn.microsoft.com/windows/win32/api/winuser/nf-winuser-registerhotkey
