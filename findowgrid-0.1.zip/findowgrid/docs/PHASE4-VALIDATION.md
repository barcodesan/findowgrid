# Phase 4 검증 결과

2026-09-28

- .NET SDK 10.0.401 / WindowsDesktop reference pack 10.0.12
- Linux에서 전체 Windows/WPF Release 교차 빌드: 성공
- 경고 0개, 오류 0개
- 실제 C# 검사: **110개 통과** — 기존 76개 + Phase 4 34개

신규 검사:

- 편집 초안의 실행 인수 deep copy
- 이름 변경 시 Workspace/창 ID와 마지막 Workspace 연결 보존
- 중복 이름·빈 창 목록 거부
- 삭제 시 마지막 ID 정리, 다른 Workspace 유지, 알 수 없는 삭제 거부
- 초안에서만 창 제거 및 transient binding 정리
- 현재 배치 업데이트 시 실제 위치·보이는 경계 캡처
- URL/인수/제목 조건 보존
- 업데이트가 창 이동/최소화나 미등록 창 캡처를 하지 않음
- 누락·모호함·캡처 실패 시 업데이트 전체 보류
- 중복 창 추가 거부, 새 창 추가 후 초안 binding 사용
- 삭제된 Workspace의 실행 중 연결 제거
- Preview 모니터 중복 제거, 화면 안쪽 배치, 종횡비, 음수 좌표 모니터 순서
- 최소화·최대화 Preview와 빈/화면 밖 데이터 처리
- 업데이트된 프레임 저장/로드, 마지막 Workspace 삭제 후 빈 문서 저장

전환/편집 검사는 fake desktop을 사용합니다. WPF XAML과 C#은 컴파일했지만 Linux에서 WPF를 실행하거나 실제 UI 스크린샷을 촬영하지 않았습니다. Windows에서 카드 줄바꿈, Preview 렌더링, 키보드 포커스, 대화상자 저장/취소, 실행 설정 중첩 저장, HTS 복원 연동을 재확인해야 합니다.

사용자는 이전 단계 완료를 보고했습니다. 이번 UI와 편집 흐름은 새로운 실물 검증 대상입니다.
