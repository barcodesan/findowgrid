# findowgrid Phase 3 검증

2026-09-28

- .NET SDK 10.0.401 및 WindowsDesktop reference pack 10.0.12
- Linux에서 전체 Windows/WPF 솔루션 Release 교차 빌드: 성공
- 경고 0개 / 오류 0개
- 실제 C# 자동 검사: **76개 통과** (기존 38개 + Phase 3 38개)

이미 열린 창을 다른 앱 실행 대기 전에 복원하는 순서도 검사했습니다.

신규 검사에는 7px 테두리로 발생하는 오른쪽 간격 재현과 보정, 전체 폭/음수 모니터/DPI 테두리, 100회 좌표 반복 무오차, 제목 조건/정규화/경로·class 불일치, 모호한 후보 거부, HWND 중복 예약, 실행 직후 프로세스·새 창·제목 변화 근거, 실행 한 번·대기 시간 초과·cooldown·취소, 전체 실행→배치 흐름, 잘못된 실행 URL/경로 거부, 기존 schema 1의 메모리 변환·원본 보존·새 경로 저장·보이는 경계 JSON 왕복 등이 포함됩니다.

실행 흐름 검사는 fake desktop/launcher를 사용합니다. 실제 Windows 프로그램을 시작한 검사는 아닙니다. URL 실제 브라우저 동작, HTS launcher가 다른 프로세스를 만드는 경우, 보호된 HTS 권한, Windows Snap 경계, WPF UI, 혼합 DPI의 DWM 보정은 아직 이 환경에서 실행하지 못했습니다.

사용자가 이전 단계에서 저장 파일 구현 성공을 보고했으며, 오른쪽 끝 배치 복원 시 간격을 보고했습니다. 이번 수정은 코드의 외곽 clamp와 Snap 일반 위치 저장 문제를 대상으로 합니다. 특정 PC의 문제가 해결됐다고 단정하지 않습니다.

재현 명령:

```powershell
dotnet build findowgrid.slnx -c Release
dotnet run --project tests/findowgrid.Checks -c Release --no-build
```
