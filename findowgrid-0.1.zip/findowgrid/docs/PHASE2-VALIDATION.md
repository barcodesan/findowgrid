# Phase 2 검증 결과

2026-09-28

- 환경: Linux, .NET SDK 10.0.401, WindowsDesktop reference pack 10.0.12
- 전체 Release 교차 빌드: 성공, 경고 0개 / 오류 0개
- C# 자동 검사: 38개 통과 (기존 Phase 1 10개 + Phase 2 28개)

Phase 2 검사에는 대상 전체 복원, 등록된 다른 Workspace 창만 최소화, 미등록 창 유지, 공유 창 보호, 복원 후 최소화 순서, 양방향 전환, 메모리 연결 없는 완전 일치 로드, 누락/실패/부분 적용 시 최소화 생략, 모호한 후보 거부, 동일 HWND 중복 할당 거부, 제목 변경 및 프로세스 수명 검증, 경로 누락 처리, 중복 최소화 방지, 동시 전환 차단, 여러 Workspace JSON 왕복, 마지막 ID 저장, 백업, revision 충돌, transient ID 미저장, 중복 이름 및 손상 JSON 거부가 포함됩니다.

전환 검사는 실제 Windows 창 대신 가짜 desktop 구현에 어떤 조작이 요청됐는지 검증합니다. Win32 실제 실행 검증과 다릅니다.

사용자는 이전 Phase 1 버전의 성공을 보고했습니다. Phase 2의 WPF UI 실행, 실제 HTS/Chrome Workspace 전환, 혼합 DPI/권한 차이, 새 최소화 경로는 이 Linux 환경에서 실행하지 못했습니다. 첨부된 Windows 검증표로 확인해야 합니다.

빌드 및 검사 명령:

```powershell
dotnet build StockZone.slnx -c Release
dotnet run --project tests/StockZone.Checks -c Release --no-build
```
