# StockZone — Phase 1 Window Engine

현재 Windows에 열린 top-level 창 하나를 선택해 배치를 저장하고, 테스트 이동 후 복원하는 개발용 프로그램입니다. Workspace 전체 앱이 아닙니다.

## 빠른 시작

1. Windows 11 x64에서 [.NET 10 SDK x64](https://dotnet.microsoft.com/download/dotnet/10.0)를 설치합니다. Desktop Runtime만으로는 소스 빌드가 불가능합니다.
2. 압축 파일을 풀고 `Run.cmd`를 실행합니다. 첫 빌드에는 NuGet 연결이 필요합니다.
3. Chrome 또는 HTS를 원하는 위치에 둡니다.
4. StockZone에서 창을 선택하고 **위치 저장 → 테스트 이동 → 저장 위치 복원** 순서로 누릅니다.

기본 권한으로 실행합니다. 관리자 권한으로 자동 승격하지 않습니다.

## 버튼 동작

- 새로고침: 현재 열린 창을 조회합니다. 이때 창을 움직이지 않습니다.
- 추가 창 표시: 제목이 없거나 tool-window 스타일인 추가 후보를 표시합니다. 숨겨진 창·다른 가상 데스크톱의 cloaked 창·시스템 셸 창은 계속 제외합니다.
- 위치 저장: 현재 선택한 창의 일반 상태 위치, 창 상태, 모니터, 식별 정보를 JSON으로 저장합니다. 기존 저장은 한 개의 `.bak`으로 보존합니다.
- 테스트 이동: 이번 실행에서 먼저 저장한 바로 그 창만 작업 영역 안으로 이동합니다. 최대화·최소화 상태였다면 일반 상태로 전환합니다.
- 저장 위치 복원: 저장한 배치를 현재 선택한 창에 적용합니다. Phase 1에서는 확인창에서 대상을 확인합니다. 앱 재실행 후에도 같은 앱의 대상 창을 직접 선택해야 합니다.

파일은 `%LOCALAPPDATA%\StockZone\Phase1\snapshot.json`에 저장합니다. HWND/PID는 파일에 기록하지 않습니다. 자동으로 기존 파일을 로드합니다. 읽을 수 없는 파일은 덮어쓰지 않고 보존하며, 안내된 파일을 옮기거나 이름을 변경한 뒤 재시작하면 새 저장이 가능합니다.

## 구현 범위

- top-level 창 탐색, 사용자 선택
- 프로세스 이름/경로, 제목, class, HWND, PID, 위치·크기, 상태, 모니터, 창 DPI 조회
- 단일 창 스냅샷 JSON 저장/로드
- 테스트 이동 및 복원
- 음수 좌표·작업 표시줄 작업 영역·최소화/최대화 처리
- 복원 결과를 최대 2초 동안 관측하고 성공/부분 적용/실패 표시
- 현재 화면 구성에 맞춘 기본 fallback

Phase 2 이후 기능인 여러 창 Workspace, 자동 매칭/실행, URL 실행, 전역 단축키, Tray, 자동 시작, 카드 preview는 포함하지 않습니다. HTS child window·브라우저 탭·계좌 데이터에 접근하지 않습니다.

## 좌표와 모니터 정책

UI는 WPF DIP를 사용하고 엔진은 PerMonitorV2 스레드 컨텍스트에서 좌표를 다룹니다. WINDOWPLACEMENT 작업 영역 좌표는 엔진 경계에서 화면 좌표로 변환합니다. WS_EX_TOOLWINDOW 예외를 구분합니다. 최소화된 창의 아이콘 좌표 대신 일반 상태 위치를 저장합니다.

동일 장치명과 모니터 영역이 확인되면 해당 모니터를 사용합니다. 그렇지 않으면 주 모니터로 이동합니다. 작업 영역이 바뀌면 상대 위치와 크기를 비율로 환산하고, 실제 작업 영역 내부로 제한합니다. 원래 여러 모니터에 걸쳐 있던 창도 한 모니터 안으로 제한됩니다. 한쪽 모니터가 주 모니터 왼쪽에 있어 좌표가 음수여도 보존합니다.

Phase 1의 `DeviceName`은 현재 연결 구성의 힌트이며 영구 ID가 아닙니다. 장치 경로 기반 매칭과 정교한 모니터 재연결 정책은 Phase 5에서 추가합니다. `WindowDpi`는 대상 창이 보고하는 값이며, DPI-unaware 앱에서는 물리 모니터 배율과 다를 수 있습니다. 물리 모니터 DPI라고 해석하지 않습니다. 해상도/배율 변경은 작업 영역 비율로 처리합니다.

## 구조

| 파일 | 역할 |
|---|---|
| src/StockZone.Engine/Interop/NativeMethods.cs | P/Invoke 및 네이티브 구조체, DPI scope |
| src/StockZone.Engine/Models/WindowModels.cs | 창/모니터/스냅샷/결과 모델 |
| src/StockZone.Engine/Services/WindowEnumerator.cs | 열거, 조회, 조작 전 대상 확인 |
| src/StockZone.Engine/Services/MonitorService.cs | 실제 모니터 영역 조회 |
| src/StockZone.Engine/Services/PlacementGeometry.cs | 순수 좌표 계산 |
| src/StockZone.Engine/Services/PlacementService.cs | 저장/이동/복원/관측 |
| src/StockZone.Engine/Storage/SnapshotStore.cs | JSON 검증과 원자적 교체 |
| src/StockZone.TestHost | WPF 테스트 UI |
| tests/StockZone.Checks | 외부 테스트 프레임워크 없는 좌표/파일 검사 |

## 빌드와 배포

`Check.cmd`는 전체 솔루션 빌드와 비네이티브 검사를 실행합니다.

```powershell
dotnet build StockZone.slnx -c Release
dotnet run --project tests/StockZone.Checks -c Release
dotnet run --project src/StockZone.TestHost -c Release
```

`Publish.cmd`는 .NET 런타임을 포함한 Windows x64 폴더를 만듭니다. `artifacts\win-x64\StockZone.TestHost.exe`를 실행합니다. 폴더 전체를 함께 보관해야 합니다. 설치 프로그램·서명·자동 업데이트는 이번 범위에 없습니다.

## 알려진 제한

- 동일 프로세스 안에서 같은 class로 HWND가 재사용되는 극히 짧은 race를 완전히 제거하지는 못합니다. 조회 직후와 조작 직전에 HWND/PID/조회 가능한 시작 시각/경로/class를 확인합니다.
- 창 제목은 매칭에 강제 사용하지 않습니다. Phase 1에서는 사용자가 직접 창을 고르고 확인합니다. 같은 앱의 잘못된 문서 창을 선택하지 않도록 확인해야 합니다.
- 외부 앱은 최소 크기를 강제하거나 위치를 되돌릴 수 있습니다. API 성공과 실제 복원 확인을 구분합니다. 오차 허용은 8px입니다.
- normal/minimized 요청은 비활성 show 명령을 사용합니다. 최대화 복원은 Windows 동작에 따라 활성 창이 바뀔 수 있습니다. foreground 우회, TOPMOST 강제, hook/injection을 사용하지 않습니다.
- 창 자체가 다르게 그려지는 DPI 처리, 앱 자체 전체 화면 모드, 보호된 HTS, 다른 가상 데스크톱 간 이동은 보장하지 않습니다.
- 창 제목/실행 경로는 로컬 JSON에 포함됩니다. 다른 사람에게 파일을 공유할 때 내용을 확인하세요. 네트워크 전송·telemetry는 없습니다.

실제 Windows 검증 절차와 기록표는 `WINDOWS-TEST-CHECKLIST.md`, 이 패키지의 확인 결과는 `VALIDATION.md`를 참고하세요.
