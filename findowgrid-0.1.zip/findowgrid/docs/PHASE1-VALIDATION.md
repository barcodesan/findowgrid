# Phase 1 검증 결과

작성일: 2026-09-28

## 수행한 검증

- Linux 환경, Microsoft .NET SDK 10.0.401 사용.
- Microsoft 공식 WindowsDesktop targeting pack 10.0.12로 Windows WPF 대상 교차 빌드.
- 전체 `StockZone.slnx` Release 빌드: 성공, 경고 0개 / 오류 0개.
- 순수 C# 실행 검사: 10개 통과.

검사 내용:
1. 음수 좌표 모니터의 정상 창 위치 보존
2. 화면 밖 oversized 창을 실제 작업 영역에 맞춤
3. 사라진 모니터 fallback 비율 및 작업 표시줄 여백 반영
4. 같은 작업 영역에서 좌표 변화 없음
5. JSON 왕복 및 최소화 해제 시 최대화 상태 보존
6. HWND/PID 영구 저장 제외
7. 파일 교체 시 직전 스냅샷 백업
8. 손상 JSON 읽기 실패 시 파일 보존
9. 미래 schema version 거부
10. 잘못된 창 크기 거부

## 미수행

- Windows에서 WPF UI 실행·화면 검증
- 실제 Win32 창 탐색·이동·복원
- Chrome 및 HTS 실물 테스트
- 실제 혼합 DPI, 모니터 분리, 권한 차이, 응답 없는 앱 테스트
- Windows에서 Publish.cmd로 self-contained 배포 생성

따라서 빌드 성공과 단위 검사 통과를 실제 Windows/HTS 호환성 검증으로 해석하지 않습니다. `WINDOWS-TEST-CHECKLIST.md`를 실행한 후 Phase 2로 진행하는 것을 권장합니다.

재현 명령(Windows .NET 10 SDK):

```powershell
dotnet build StockZone.slnx -c Release
dotnet run --project tests/StockZone.Checks -c Release --no-build
```
