# StockZone — Phase 2 Workspaces

사용자가 직접 배치한 여러 Windows top-level 창을 하나의 Workspace로 저장하고 다시 복원합니다. 금융 데이터·HTS 내부 화면·브라우저 탭을 읽거나 제어하지 않습니다.

## 실행

Windows 11 x64와 .NET 10 SDK x64를 사용합니다. Phase 1을 실행했던 환경이면 같은 방식으로 실행하면 됩니다.

1. 이 ZIP을 새 폴더에 풉니다. 이전 Phase 1 폴더 위에 덮어쓸 필요가 없습니다.
2. `Run.cmd`를 실행합니다.
3. HTS·Chrome 등 필요한 창을 직접 원하는 위치에 배치합니다.
4. StockZone의 **새로고침**을 누르고 저장할 창만 체크합니다.
5. 이름(예: FX)을 입력하고 **Save Current Workspace**를 누릅니다.
6. 창 위치를 바꾼 후 왼쪽에서 FX를 선택하고 **OPEN**을 누릅니다.

창을 체크하지 않으면 저장 버튼이 비활성화됩니다. 이름은 서로 달라야 합니다. 저장은 현재 실제 배치를 다시 읽으므로 목록을 읽은 뒤 창을 움직였더라도 저장 버튼을 누른 시점의 배치를 사용합니다.

## 두 Workspace로 전환 시험

1. 창 A와 공유 창 C를 배치하고 FX로 저장합니다.
2. 창 B와 공유 창 C를 다른 배치로 만들고 Macro로 저장합니다. 이전에 최소화된 창은 직접 열어 원하는 상태로 준비하세요.
3. FX의 OPEN: A와 C가 FX 배치로 복원되고, Macro에만 속한 B는 최소화됩니다.
4. Macro의 OPEN: B와 C가 Macro 배치로 복원되고, FX에만 속한 A는 최소화됩니다.
5. 어디에도 등록하지 않은 메모장 등의 창이 그대로인지 확인합니다.

C처럼 두 Workspace가 공유하는 창은 현재 Workspace의 배치가 우선하며 최소화하지 않습니다. 프로그램 종류로 금융/일반 앱을 자동 분류하지 않습니다. Discord나 PDF도 사용자가 등록했다면 관리 대상입니다.

저장할 때 최소화 상태였던 창은 OPEN 후에도 최소화 상태로 돌아갑니다. 보고 싶은 창은 펼쳐 놓고 저장하세요.

## Phase 2의 창 연결 범위

- StockZone 실행 중 저장한 창: 메모리에 보관한 HWND와 PID/조회 가능한 프로세스 시작 시각/경로/class를 확인해 재사용합니다. 제목이 바뀌어도 같은 실행 창이면 유지합니다.
- StockZone 재시작 또는 `JSON 다시 불러오기` 후: 실행 경로·프로세스 이름·class·제목이 정확히 일치하는 유일한 창만 연결합니다.
- 동일한 후보가 여러 개이거나, 여러 저장 항목이 한 창을 가리키면 해당 항목을 건너뜁니다.
- 경로 또는 제목을 조회할 수 없는 창은 재시작 후 자동 연결하지 않습니다. 현재 실행 중 직접 선택해 저장한 창은 사용할 수 있습니다.
- 닫힌 앱을 자동 실행하지 않습니다. 브라우저 URL도 아직 실행하지 않습니다. 수동으로 앱을 열고 저장 당시 제목을 확인해야 합니다.

이는 Phase 2 복원을 위한 보수적인 완전 일치 연결입니다. 제목 패턴·유사도 점수·실행 명령·URL·창 생성 대기·자동 앱 실행은 Phase 3에서 구현합니다.

## 전환 안전성

먼저 대상 Workspace의 창을 모두 확인한 뒤 최대 4개씩 복원합니다. 복원 결과는 기존 Phase 1 엔진으로 관측합니다.

- 모든 대상 창의 복원이 확인된 후 다른 Workspace의 확인 가능한 등록 창만 최소화합니다.
- 하나라도 찾지 못하거나 복원이 실패/부분 적용이면 다른 Workspace 창의 최소화를 전부 생략합니다.
- 복원된 대상이 도중에 닫혔으면 다른 창 최소화를 시작하지 않습니다.
- 이미 성공한 창의 복원을 되돌리는 트랜잭션 rollback은 하지 않습니다. 결과 표에 항목별 성공/실패를 표시합니다.
- 다른 Workspace 쪽에서 모호하거나 없는 창은 건드리지 않습니다.
- 등록하지 않은 창의 위치·상태·Z-order를 의도적으로 변경하지 않습니다. 다른 창이 최소화됨에 따라 화면에 드러나는 것은 Windows의 정상 동작입니다.
- 같은 실행 인스턴스의 겹치는 OPEN은 차단합니다. 테스트 중에는 StockZone을 하나만 실행하세요. 서로 다른 인스턴스의 OS 창 조작은 전역으로 직렬화하지 않습니다.

일반 상태/최소화는 비활성 명령을 사용합니다. 최대화 복원은 Windows 동작에 따라 활성 창이 바뀔 수 있습니다. 강제 foreground 전환 기능은 아직 없습니다.

## 데이터

`%LOCALAPPDATA%\StockZone\workspaces.json`

- Workspace 이름·ID·창 배치 목록
- 식별 정보(실행 경로·프로세스 이름·class·제목)
- 모니터 영역·DPI 관련 창 정보
- 마지막으로 완전히 복원된 Workspace ID
- schema version 및 저장 revision

HWND와 PID는 저장하지 않습니다. JSON은 사람이 읽을 수 있는 snake_case 형식입니다. 직전 파일은 `.bak`에 보관합니다. 임시 파일을 먼저 기록하고 원자적으로 교체합니다.

다른 인스턴스가 먼저 저장하면 오래된 revision으로 덮어쓰지 않습니다. JSON 다시 불러오기로 최신 목록을 읽은 뒤 다시 저장하세요. 손상 파일·지원하지 않는 schema는 자동 덮어쓰지 않습니다. 백업에서 수동 복구하거나 해당 파일을 옮긴 다음 다시 불러올 수 있습니다. 읽기 오류가 있으면 UI의 저장·OPEN을 중단합니다.

마지막 Workspace ID는 시작 시 목록 선택에만 사용합니다. 자동 복원·자동 시작은 Phase 5 범위입니다. Phase 1의 `%LOCALAPPDATA%\StockZone\Phase1\snapshot.json`은 그대로 유지되며 Workspace로 자동 변환하지 않습니다.

파일에는 창 제목과 실행 경로가 포함됩니다. 프로그램은 이를 외부로 전송하지 않습니다.

## 구현 구조

| 파일 | 역할 |
|---|---|
| Engine/Models/WorkspaceModels.cs | Workspace·항목·저장 문서·전환 결과 |
| Engine/Storage/WorkspaceStore.cs | 검증, JSON, 백업, revision 충돌 방지 |
| Engine/Services/WorkspaceService.cs | 여러 창 캡처·복원·전환 정책 |
| Engine/Services/ExactWindowResolver.cs | 현재 실행 창 연결 / 유일한 완전 일치 |
| Engine/Services/IWindowDesktop.cs | 전환 정책의 독립 검사 경계 |
| Engine/Services/WindowsDesktop.cs | Phase 1 엔진 연결 |
| TestHost/WorkspaceWindow.xaml | Phase 2 테스트 UI |
| TestHost/MainWindow.xaml | 기존 Phase 1 단일 창 진단 화면 |
| tests/StockZone.Checks | 좌표·저장·전환 정책 자동 검사 |

`단일 창 테스트` 버튼은 기존 Phase 1 화면을 엽니다. 진단 화면을 닫으면 Workspace 화면으로 돌아옵니다.

## 빌드

```powershell
dotnet build StockZone.slnx -c Release
dotnet run --project tests/StockZone.Checks -c Release
dotnet run --project src/StockZone.TestHost -c Release
```

`Check.cmd`는 빌드와 자동 검사, `Publish.cmd`는 self-contained Windows x64 출력용입니다. 후자의 결과 폴더 전체를 배포해야 합니다. SDK 없이 소스 ZIP을 바로 실행할 수는 없습니다.

## 이번 단계에서 아직 없는 기능

프로그램 자동 실행, 고급 매칭, URL 실행, Workspace 카드/preview, Edit/Update, 창 추가·제거 편집, 단축키, Tray, 자동 시작, 자동 세션 복원은 포함하지 않았습니다. 같은 Workspace를 수정하는 기능은 Phase 4에서 구현하며 지금은 새 이름으로 저장합니다. UI는 Phase 2 검증용입니다.

모니터와 DPI는 Phase 1 정책을 유지합니다. 현재 장치명+영역 힌트로 연결하고, 불일치 시 주 모니터 작업 영역으로 비율 보정합니다. 영구 모니터 장치 경로 및 정교한 재연결 처리는 Phase 5 대상입니다.

`VALIDATION.md`는 개발 환경 검증 결과, `WINDOWS-TEST-CHECKLIST.md`는 실물 검증 절차입니다. Phase 1 안내는 `docs`에 보존했습니다.
