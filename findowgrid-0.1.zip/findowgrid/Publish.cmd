@echo off
setlocal
cd /d "%~dp0"
dotnet publish src\findowgrid.TestHost\findowgrid.TestHost.csproj -c Release -r win-x64 --self-contained true -o artifacts\win-x64
if errorlevel 1 (
 echo Publish failed.
 pause
 exit /b 1
)
echo Open artifacts\win-x64\findowgrid.exe
pause
