using System.Diagnostics;
using findowgrid.Engine.Models;
namespace findowgrid.Engine.Services;
public sealed class WindowLauncher : IWindowLauncher
{
    public Task<LaunchTicket> LaunchAsync(LaunchSpec spec,CancellationToken cancellationToken) => Task.Run(() =>
    {
        cancellationToken.ThrowIfCancellationRequested();
        LaunchValidation.Validate(spec);
        ProcessStartInfo info;
        if(spec.Kind==LaunchKind.Url && string.IsNullOrWhiteSpace(spec.BrowserPath))
            info=new(spec.Url!) { UseShellExecute=true };
        else
        {
            var path=spec.Kind==LaunchKind.Application ? spec.ExecutablePath : spec.BrowserPath;
            if(path==null || !File.Exists(path)) throw new FileNotFoundException("실행 파일을 찾을 수 없습니다. 실행 설정에서 경로를 확인하세요.");
            info=new(path) { UseShellExecute=false };
            if(!string.IsNullOrWhiteSpace(spec.WorkingDirectory)) info.WorkingDirectory=spec.WorkingDirectory;
            foreach(var arg in spec.Arguments ?? []) info.ArgumentList.Add(arg);
            if(spec.Kind==LaunchKind.Url) info.ArgumentList.Add(spec.Url!);
        }
        if(spec.Kind==LaunchKind.None) throw new InvalidOperationException("실행 정보가 없습니다.");
        // Never assemble shell command strings, elevate, inject, or read a browser session.
        using var process=Process.Start(info);
        uint? pid=null;
        try { if(process!=null) pid=(uint)process.Id; } catch(InvalidOperationException) { }
        return new LaunchTicket(pid,"실행 요청을 보냈습니다. 창 생성을 기다립니다.");
    },cancellationToken);
}
