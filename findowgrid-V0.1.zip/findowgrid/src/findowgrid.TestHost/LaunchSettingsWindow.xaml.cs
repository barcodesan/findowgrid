using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using findowgrid.Engine.Models;
using findowgrid.Engine.Services;
using findowgrid.Engine.Storage;
using Entry = findowgrid.Engine.Models.WorkspaceWindow;
namespace findowgrid.TestHost;
public partial class LaunchSettingsWindow : Window
{
    private readonly Workspace original;
    private readonly List<Entry> entries;
    private int editing=-1;
    private bool changing;
    public Workspace? EditedWorkspace { get; private set; }
    public LaunchSettingsWindow(Workspace workspace, int selectedIndex=0)
    {
        InitializeComponent(); original=workspace; entries=workspace.Windows.ToList();
        Entries.ItemsSource=entries; Entries.SelectedIndex=Math.Clamp(selectedIndex,0,entries.Count-1);
    }
    private void Entry_Changed(object sender,SelectionChangedEventArgs e)
    {
        if(changing || ExePath==null) return;
        int next=Entries.SelectedIndex;
        if(editing>=0 && !ApplyCurrent())
        { changing=true; Entries.SelectedIndex=editing; changing=false; return; }
        editing=next; if(next<0) return;
        var entry=entries[next]; var spec=entry.Launch ?? WorkspaceService.DefaultLaunch(entry.Snapshot.Identity);
        TitleContains.Text=entry.Match?.TitleContains ?? "";
        Kind.SelectedIndex=spec.Kind switch { LaunchKind.Application=>0,LaunchKind.Url=>1,_=>2 };
        AutoLaunch.IsChecked=spec.Behavior==LaunchBehavior.LaunchIfMissing;
        ExePath.Text=spec.ExecutablePath ?? entry.Snapshot.Identity.ExecutablePath ?? "";
        Url.Text=spec.Url ?? ""; BrowserPath.Text=spec.BrowserPath ?? "";
        Arguments.Text=string.Join(Environment.NewLine,spec.Arguments ?? []);
        WorkingDirectory.Text=spec.WorkingDirectory ?? ""; WaitSeconds.Text=spec.WaitSeconds.ToString(); Error.Text="";
    }
    private bool ApplyCurrent()
    {
        if(editing<0) return true;
        try
        {
            if(!int.TryParse(WaitSeconds.Text,out int seconds)) throw new ArgumentException("대기 시간은 숫자로 입력하세요.");
            string? Optional(string text)=>string.IsNullOrWhiteSpace(text) ? null : text.Trim();
            var kind=Kind.SelectedIndex switch { 0=>LaunchKind.Application,1=>LaunchKind.Url,_=>LaunchKind.None };
            var spec=new LaunchSpec(kind,Optional(ExePath.Text),Arguments.Text.Replace("\r","").Split('\n').Where(a=>a.Length>0).ToList(),
                Optional(WorkingDirectory.Text),Optional(Url.Text),Optional(BrowserPath.Text),
                AutoLaunch.IsChecked==true ? LaunchBehavior.LaunchIfMissing : LaunchBehavior.ReuseOnly,seconds);
            var updated=entries[editing] with { Launch=spec,Match=new(Optional(TitleContains.Text)) };
            WorkspaceStore.Validate(new(2,0,null,[original with { Windows=[updated] }]));
            entries[editing]=updated; Error.Text=""; return true;
        }
        catch(Exception ex) { Error.Text=ex.Message; return false; }
    }
    private void Save_Click(object sender,RoutedEventArgs e)
    {
        if(!ApplyCurrent()) return;
        EditedWorkspace=original with { Windows=entries,UpdatedAt=DateTimeOffset.UtcNow };
        DialogResult=true;
    }
    private void BrowseExe_Click(object sender,RoutedEventArgs e) { var p=Browse(); if(p!=null) ExePath.Text=p; }
    private void BrowseBrowser_Click(object sender,RoutedEventArgs e) { var p=Browse(); if(p!=null) BrowserPath.Text=p; }
    private string? Browse()
    {
        var dialog=new OpenFileDialog { Filter="프로그램 (*.exe)|*.exe",CheckFileExists=true };
        return dialog.ShowDialog(this)==true ? dialog.FileName : null;
    }
}
