using System.Text.Json;
using findowgrid.Engine.Models;
using findowgrid.Engine.Services;
using findowgrid.Engine.Storage;
int passed = 0;
void Check(bool success, string name) { if (!success) throw new Exception("FAIL: "+name); Console.WriteLine("PASS: "+name); passed++; }
var left = new PixelRect(-1920,0,1920,1040);
Check(PlacementGeometry.Clamp(new(-1800,30,1000,800),left)==new PixelRect(-1800,30,1000,800),"negative monitor coordinates preserved");
Check(PlacementGeometry.Clamp(new(9999,9999,2200,1600),left)==left,"offscreen oversized window fits real work area");
Check(PlacementGeometry.Map(new(-1920,0,960,520),left,new(0,40,1280,680))==new PixelRect(0,40,640,340),"missing monitor fallback scales and respects taskbar");
Check(PlacementGeometry.Map(new(100,100,800,600),new(0,0,1920,1080),new(0,0,1920,1080))==new PixelRect(100,100,800,600),"unchanged monitor does not drift");
var path = Path.Combine(Path.GetTempPath(),"findowgrid-check-"+Guid.NewGuid().ToString("N"),"snapshot.json");
try
{
    var store = new SnapshotStore(path);
    var s = new WindowSnapshot(1,DateTimeOffset.UtcNow,new("chrome","C:\\Chrome\\chrome.exe","Chrome_WidgetWin_1","TradingView"),new(-1800,30,1000,800),WindowState.Minimized,true,new("DISPLAY2",left,left,false),144);
    store.Save(s); Check(store.Load()==s,"JSON roundtrip including minimized restore-to-maximized");
    string json = File.ReadAllText(path);
    Check(!json.Contains("Handle") && !json.Contains("ProcessId"),"no transient HWND or PID persisted");
    store.Save(s with { State=WindowState.Normal });
    Check(File.Exists(path+".bak") && new SnapshotStore(path+".bak").Load()==s,"atomic replacement keeps previous snapshot");
    File.WriteAllText(path,"{broken");
    try { store.Load(); throw new Exception("Corruption accepted"); } catch (JsonException) { }
    Check(File.ReadAllText(path)=="{broken","corrupt file remains untouched");
    try { SnapshotStore.Validate(s with { SchemaVersion=99 }); throw new Exception("Version accepted"); } catch (InvalidDataException) { }
    Check(true,"future schema rejected");
    try { SnapshotStore.Validate(s with { NormalBoundsScreenPx=new(0,0,0,50) }); throw new Exception("Invalid rect accepted"); } catch (InvalidDataException) { }
    Check(true,"invalid dimensions rejected");
}
finally { Directory.Delete(Path.GetDirectoryName(path)!,true); }
passed += await WorkspaceChecks.Run();
passed += await Phase3Checks.Run();
passed += await Phase4Checks.Run();
passed += Phase5Checks.Run();
Console.WriteLine($"{passed} checks passed. Native Windows behavior requires the manual checklist.");
